import { appendFileSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";

export function loadEnv(path = ".env"): void {
  const envPath = resolve(process.cwd(), path);
  if (!existsSync(envPath)) return;

  const content = readFileSync(envPath, "utf8");
  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const separator = trimmed.indexOf("=");
    if (separator === -1) continue;

    const key = trimmed.slice(0, separator).trim();
    const rawValue = trimmed.slice(separator + 1).trim();
    const value = rawValue.replace(/^["']|["']$/g, "");
    if (key && process.env[key] === undefined) {
      process.env[key] = value;
    }
  }
}

export function setEnvValue(key: string, value: string, path = ".env"): void {
  const envPath = resolve(process.cwd(), path);
  const escapedValue = value.replace(/\r?\n/g, "").trim();
  const line = `${key}=${escapedValue}`;

  if (!existsSync(envPath)) {
    writeFileSync(envPath, `${line}\n`, "utf8");
    process.env[key] = escapedValue;
    return;
  }

  const content = readFileSync(envPath, "utf8");
  const lines = content.split(/\r?\n/);
  let replaced = false;
  const nextLines = lines.map((existing) => {
    const trimmed = existing.trim();
    if (trimmed.startsWith(`${key}=`)) {
      replaced = true;
      return line;
    }
    return existing;
  });

  if (replaced) {
    writeFileSync(envPath, `${nextLines.join("\n").replace(/\n*$/g, "")}\n`, "utf8");
  } else {
    appendFileSync(envPath, `${content.endsWith("\n") ? "" : "\n"}${line}\n`, "utf8");
  }

  process.env[key] = escapedValue;
}
