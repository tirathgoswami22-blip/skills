import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { z } from "zod";
import { SkillError } from "./protocol.js";

const BrowserUseRunSchema = z.object({
  task: z.string().min(1),
  maxSteps: z.number().int().min(1).max(80).optional()
});

export class BrowserUseSkill {
  async execute(action: string, params: Record<string, unknown>): Promise<unknown> {
    switch (action) {
      case "browserUse.run":
        return this.run(params);
      default:
        throw new SkillError("UNKNOWN_BROWSER_USE_ACTION", `Unknown browser-use action: ${action}`);
    }
  }

  private async run(params: Record<string, unknown>): Promise<unknown> {
    if (process.env.JARVIS_BROWSER_USE === "off") {
      throw new SkillError("BROWSER_USE_DISABLED", "browser-use engine is disabled. Set JARVIS_BROWSER_USE=on.");
    }

    const parsed = BrowserUseRunSchema.parse(params);
    const python = resolve(process.cwd(), process.env.JARVIS_BROWSER_USE_PYTHON ?? ".venv-browser-use\\Scripts\\python.exe");
    const runner = resolve(process.cwd(), process.env.JARVIS_BROWSER_USE_RUNNER ?? "browser_use_runner\\runner.py");

    if (!existsSync(python)) {
      throw new SkillError("BROWSER_USE_PYTHON_MISSING", "browser-use Python venv missing. Install it first.", { python });
    }
    if (!existsSync(runner)) {
      throw new SkillError("BROWSER_USE_RUNNER_MISSING", "browser-use runner missing.", { runner });
    }

    const args = [runner, "--task", parsed.task];
    if (parsed.maxSteps !== undefined) {
      args.push("--max-steps", String(parsed.maxSteps));
    }

    return runJsonProcess(python, args, {
      ...process.env,
      BROWSER_USE_CONFIG_DIR: resolve(process.cwd(), process.env.BROWSER_USE_CONFIG_DIR ?? ".jarvis\\browser-use"),
      GOOGLE_API_KEY: process.env.GOOGLE_API_KEY ?? process.env.GEMINI_API_KEY ?? ""
    });
  }
}

function runJsonProcess(command: string, args: string[], env: NodeJS.ProcessEnv): Promise<unknown> {
  return new Promise((resolvePromise, reject) => {
    const child = spawn(command, args, {
      cwd: process.cwd(),
      env,
      windowsHide: false
    });
    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (chunk) => {
      stdout += String(chunk);
    });
    child.stderr.on("data", (chunk) => {
      const text = String(chunk);
      stderr += text;
      process.stdout.write(text);
    });
    child.on("error", reject);
    child.on("exit", (code) => {
      const parsed = parseLastJsonLine(stdout);
      if (code === 0 && parsed !== undefined) {
        resolvePromise(parsed);
        return;
      }
      if (parsed && typeof parsed === "object" && "error" in parsed) {
        reject(new SkillError("BROWSER_USE_FAILED", String((parsed as { error: unknown }).error), parsed));
        return;
      }
      reject(
        new SkillError("BROWSER_USE_FAILED", stderr.trim() || stdout.trim() || `browser-use runner exited with ${code}`, {
          code,
          stdout: stdout.slice(-4000),
          stderr: stderr.slice(-4000)
        })
      );
    });
  });
}

function parseLastJsonLine(output: string): unknown {
  for (const line of output.trim().split(/\r?\n/).reverse()) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("{")) continue;
    try {
      return JSON.parse(trimmed);
    } catch {
      continue;
    }
  }
  return undefined;
}
