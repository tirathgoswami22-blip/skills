import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import { isAbsolute, resolve } from "node:path";
import { chromium, type Browser, type BrowserContext, type Page } from "playwright";
import { z } from "zod";
import { SkillError } from "./protocol.js";

const OpenSchema = z.object({
  headless: z.boolean().default(false),
  url: z.string().optional()
});

const NavigateSchema = z.object({
  url: z.string().min(1)
});

const SearchSchema = z.object({
  query: z.string().min(1),
  engine: z.enum(["google", "youtube"]).default("google")
});

const SwitchTabSchema = z.object({
  index: z.number().int().min(0).optional(),
  urlIncludes: z.string().optional(),
  titleIncludes: z.string().optional()
});

const ClickSchema = z.preprocess((value) => {
  if (!value || typeof value !== "object" || Array.isArray(value)) return value;
  const params = value as Record<string, unknown>;
  return {
    ...params,
    text:
      params.text ??
      params.link_text ??
      params.linkText ??
      params.button_text ??
      params.buttonText ??
      params.label ??
      params.name ??
      params.title
  };
}, z.object({
  text: z.string().min(1),
  exact: z.boolean().default(false),
  role: z.enum(["button", "link", "tab", "menuitem"]).optional()
}));

const TypeSchema = z.preprocess((value) => {
  if (!value || typeof value !== "object" || Array.isArray(value)) return value;
  const params = value as Record<string, unknown>;
  return {
    ...params,
    target: params.target ?? params.field ?? params.input ?? params.label ?? params.placeholder ?? params.name
  };
}, z.object({
  target: z.string().min(1),
  text: z.string(),
  submit: z.boolean().default(false),
  clear: z.boolean().default(true)
}));

const RefSchema = z.object({
  ref: z.string().regex(/^e\d+$/),
  text: z.string().optional(),
  submit: z.boolean().default(false),
  clear: z.boolean().default(true)
});

const SelectorSchema = z.object({
  selector: z.string().min(1),
  text: z.string().optional(),
  submit: z.boolean().default(false),
  clear: z.boolean().default(true)
});

const KeySchema = z.object({
  key: z.string().min(1)
});

const ScrollSchema = z.object({
  direction: z.enum(["up", "down", "top", "bottom"]).default("down"),
  amount: z.number().int().positive().default(3)
});

const VideoSchema = z.object({
  command: z.enum(["play", "pause", "toggle", "seek"]),
  seconds: z.number().optional()
});

const YouTubeCommentSchema = z.object({
  text: z.string().min(1),
  submit: z.boolean().default(true)
});

type Snapshot = {
  activeTab: number;
  tabs: Array<{ index: number; title: string; url: string }>;
  page: {
    title: string;
    url: string;
    text: string;
    links: string[];
    buttons: string[];
    inputs: Array<{ label: string; placeholder: string; name: string; type: string }>;
    elements: Array<{
      ref: string;
      selector: string;
      tag: string;
      role: string;
      text: string;
      label: string;
      placeholder: string;
      name: string;
      href: string;
      type: string;
      rect: { x: number; y: number; width: number; height: number };
      html: string;
    }>;
    videos: Array<{ index: number; paused: boolean; currentTime: number; duration: number | null }>;
  };
};

export class BrowserSkill {
  private browser?: Browser;
  private context?: BrowserContext;
  private activePage?: Page;
  private persistentContext = false;
  private cdpMode = false;

  async execute(action: string, params: Record<string, unknown>): Promise<unknown> {
    switch (action) {
      case "browser.open":
        return this.open(params);
      case "browser.close":
        return this.close();
      case "tab.new":
        return this.newTab(params);
      case "tab.close":
        return this.closeTab();
      case "tab.list":
        return this.listTabs();
      case "tab.switch":
        return this.switchTab(params);
      case "page.navigate":
        return this.navigate(params);
      case "page.search":
        return this.search(params);
      case "page.snapshot":
        return this.snapshot();
      case "page.extract":
        return this.extract();
      case "page.click":
        return this.click(params);
      case "page.clickRef":
        return this.clickRef(params);
      case "page.clickSelector":
        return this.clickSelector(params);
      case "page.type":
        return this.type(params);
      case "page.typeRef":
        return this.typeRef(params);
      case "page.typeSelector":
        return this.typeSelector(params);
      case "page.key":
        return this.pressKey(params);
      case "page.scroll":
        return this.scroll(params);
      case "video.control":
        return this.videoControl(params);
      case "youtube.comment":
        return this.youtubeComment(params);
      default:
        throw new SkillError("UNKNOWN_ACTION", `Unknown browser skill action: ${action}`);
    }
  }

  private async ensurePage(): Promise<Page> {
    if (this.browser && !this.browser.isConnected()) {
      this.browser = undefined;
      this.context = undefined;
      this.activePage = undefined;
      this.persistentContext = false;
      this.cdpMode = false;
    }

    if (!this.context || (!this.browser && !this.persistentContext) || !this.activePage) {
      await this.open({ headless: false });
    }

    if (!this.activePage || this.activePage.isClosed()) {
      const pages = this.context?.pages() ?? [];
      this.activePage = pages.find((page) => !page.isClosed()) ?? (await this.context!.newPage());
    }

    return this.activePage;
  }

  private async open(params: Record<string, unknown>) {
    const parsed = OpenSchema.parse(params);

    if (!this.context) {
      if (process.env.JARVIS_CHROME_MODE === "cdp") {
        await this.openCdp(parsed.headless);
      } else if (process.env.JARVIS_CHROME_MODE === "persistent") {
        const userDataDir = expandEnvPath(
          process.env.JARVIS_CHROME_USER_DATA_DIR ?? "%LOCALAPPDATA%\\Google\\Chrome\\User Data"
        );
        const profile = process.env.JARVIS_CHROME_PROFILE ?? "Default";
        this.context = await chromium.launchPersistentContext(userDataDir, {
          headless: parsed.headless,
          channel: process.env.JARVIS_CHROME_CHANNEL ?? "chrome",
          viewport: null,
          args: [`--profile-directory=${profile}`]
        });
        this.browser = this.context.browser() ?? undefined;
        this.persistentContext = true;
        this.activePage = this.context.pages().find((page) => !page.isClosed()) ?? (await this.context.newPage());
      } else {
        this.browser = await chromium.launch({
          headless: parsed.headless,
          channel: process.env.JARVIS_CHROME_CHANNEL ?? "chrome"
        }).catch(async () => {
          return chromium.launch({ headless: parsed.headless });
        });
        this.context = await this.browser.newContext();
        this.activePage = await this.context.newPage();
      }
    }

    if (parsed.url) {
      await this.activePage!.goto(normalizeUrl(parsed.url), { waitUntil: "domcontentloaded" });
    }

    return this.snapshot();
  }

  private async close() {
    if (this.cdpMode) {
      // In CDP mode this may be the user's real Chrome. Disconnect by dropping references only.
    } else if (this.persistentContext) {
      await this.context?.close();
    } else {
      await this.browser?.close();
    }
    this.browser = undefined;
    this.context = undefined;
    this.activePage = undefined;
    this.persistentContext = false;
    this.cdpMode = false;
    return { closed: true };
  }

  private async openCdp(headless: boolean) {
    if (headless) {
      throw new SkillError("CDP_HEADLESS_UNSUPPORTED", "CDP mode uses visible installed Chrome, not headless mode.");
    }

    const port = Number(process.env.JARVIS_CHROME_DEBUG_PORT ?? "9222");
    const endpoint = `http://127.0.0.1:${port}`;

    this.browser = await connectToCdp(endpoint).catch(async () => {
      launchChromeForCdp(port);
      await sleep(1500);
      return connectToCdp(endpoint).catch((error) => {
        const message = error instanceof Error ? error.message : String(error);
        throw new SkillError(
          "CHROME_CDP_UNAVAILABLE",
          "Chrome debug port is not available. Close all normal Chrome windows, run `npm.cmd run chrome:debug`, then run Jarvis again.",
          { endpoint, originalError: message }
        );
      });
    });

    this.context = this.browser.contexts()[0] ?? (await this.browser.newContext());
    this.activePage = this.context.pages().find((page) => !page.isClosed()) ?? (await this.context.newPage());
    this.persistentContext = false;
    this.cdpMode = true;
  }

  private async newTab(params: Record<string, unknown>) {
    const parsed = NavigateSchema.partial().parse(params);
    const context = await this.contextOrOpen();
    const page = await context.newPage();
    this.activePage = page;
    if (parsed.url) {
      await page.goto(normalizeUrl(parsed.url), { waitUntil: "domcontentloaded" });
    }
    return this.snapshot();
  }

  private async closeTab() {
    const page = await this.ensurePage();
    await page.close();
    const pages = this.context!.pages().filter((candidate) => !candidate.isClosed());
    this.activePage = pages.at(-1) ?? (await this.context!.newPage());
    return this.snapshot();
  }

  private async listTabs() {
    await this.ensurePage();
    return this.tabs();
  }

  private async switchTab(params: Record<string, unknown>) {
    const parsed = SwitchTabSchema.parse(params);
    await this.ensurePage();
    const pages = this.context!.pages();

    let page: Page | undefined;
    if (parsed.index !== undefined) {
      page = pages[parsed.index];
    } else if (parsed.urlIncludes) {
      page = pages.find((candidate) => candidate.url().includes(parsed.urlIncludes!));
    } else if (parsed.titleIncludes) {
      for (const candidate of pages) {
        if ((await candidate.title()).toLowerCase().includes(parsed.titleIncludes.toLowerCase())) {
          page = candidate;
          break;
        }
      }
    }

    if (!page) {
      throw new SkillError("TAB_NOT_FOUND", "Could not find the requested tab.", parsed);
    }

    this.activePage = page;
    await page.bringToFront();
    return this.snapshot();
  }

  private async navigate(params: Record<string, unknown>) {
    const parsed = NavigateSchema.parse(params);
    const page = await this.ensurePage();
    await page.goto(normalizeUrl(parsed.url), { waitUntil: "domcontentloaded" });
    return this.snapshot();
  }

  private async search(params: Record<string, unknown>) {
    const parsed = SearchSchema.parse(params);
    const page = await this.ensurePage();
    const url =
      parsed.engine === "youtube"
        ? `https://www.youtube.com/results?search_query=${encodeURIComponent(parsed.query)}`
        : `https://www.google.com/search?q=${encodeURIComponent(parsed.query)}`;
    await page.goto(url, { waitUntil: "domcontentloaded" });
    return this.snapshot();
  }

  private async snapshot(): Promise<Snapshot> {
    const page = await this.ensurePage();
    await page.waitForLoadState("domcontentloaded").catch(() => undefined);

    const [title, pageData] = await Promise.all([
      page.title(),
      page.evaluate(() => {
        const clean = (value: string | null | undefined) => (value ?? "").replace(/\s+/g, " ").trim();
        const visible = (element: Element) => {
          const style = window.getComputedStyle(element);
          const rect = element.getBoundingClientRect();
          return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
        };

        const text = clean(document.body?.innerText).slice(0, 12000);
        const links = Array.from(document.querySelectorAll("a"))
          .filter(visible)
          .map((element) => clean(element.textContent))
          .filter(Boolean)
          .slice(0, 80);
        const buttons = Array.from(document.querySelectorAll("button, [role='button'], input[type='button'], input[type='submit']"))
          .filter(visible)
          .map((element) => clean(element.textContent || element.getAttribute("value") || element.getAttribute("aria-label")))
          .filter(Boolean)
          .slice(0, 80);
        const inputs = Array.from(document.querySelectorAll("input, textarea, select"))
          .filter(visible)
          .map((element) => ({
            label: clean(
              element.id
                ? document.querySelector(`label[for="${CSS.escape(element.id)}"]`)?.textContent
                : element.closest("label")?.textContent
            ),
            placeholder: clean(element.getAttribute("placeholder")),
            name: clean(element.getAttribute("name")),
            type: clean(element.getAttribute("type") || element.tagName.toLowerCase())
          }))
          .slice(0, 60);
        const elements = interactiveElements()
          .map((element, index) => {
            const htmlElement = element as HTMLElement;
            const input = element as HTMLInputElement;
            const rect = element.getBoundingClientRect();
            return {
              ref: `e${index}`,
              selector: uniqueSelector(element),
              tag: element.tagName.toLowerCase(),
              role: clean(element.getAttribute("role")),
              text: clean(element.textContent || element.getAttribute("aria-label") || input.value).slice(0, 220),
              label: clean(
                element.id
                  ? document.querySelector(`label[for="${CSS.escape(element.id)}"]`)?.textContent
                  : element.closest("label")?.textContent
              ).slice(0, 160),
              placeholder: clean(element.getAttribute("placeholder")),
              name: clean(element.getAttribute("name")),
              href: element instanceof HTMLAnchorElement ? element.href : "",
              type: clean(element.getAttribute("type") || htmlElement.getAttribute("aria-label")),
              rect: {
                x: Math.round(rect.x),
                y: Math.round(rect.y),
                width: Math.round(rect.width),
                height: Math.round(rect.height)
              },
              html: clean(htmlElement.outerHTML).slice(0, 500)
            };
          })
          .filter((element) => element.text || element.label || element.placeholder || element.name || element.href)
          .slice(0, 160);
        const videos = Array.from(document.querySelectorAll("video")).map((video, index) => ({
          index,
          paused: video.paused,
          currentTime: video.currentTime,
          duration: Number.isFinite(video.duration) ? video.duration : null
        }));

        return { text, links, buttons, inputs, elements, videos };

        function interactiveElements() {
          return Array.from(
            document.querySelectorAll(
              [
                "a",
                "button",
                "[role='button']",
                "[role='link']",
                "[role='tab']",
                "[role='menuitem']",
                "input",
                "textarea",
                "select",
                "[contenteditable='true']",
                "[tabindex]:not([tabindex='-1'])",
                "video"
              ].join(", ")
            )
          ).filter(visible);
        }

        function uniqueSelector(element: Element) {
          if (element.id) return `#${CSS.escape(element.id)}`;
          const parts: string[] = [];
          let current: Element | null = element;
          while (current && current.nodeType === Node.ELEMENT_NODE && parts.length < 5) {
            let part = current.tagName.toLowerCase();
            const attr =
              current.getAttribute("name") ||
              current.getAttribute("aria-label") ||
              current.getAttribute("placeholder") ||
              current.getAttribute("role");
            if (attr) {
              part += `[${current.getAttribute("name") ? "name" : current.getAttribute("aria-label") ? "aria-label" : current.getAttribute("placeholder") ? "placeholder" : "role"}="${CSS.escape(attr)}"]`;
              parts.unshift(part);
              break;
            }
            const parent: Element | null = current.parentElement;
            if (parent) {
              const siblings = Array.from(parent.children as HTMLCollectionOf<Element>).filter(
                (child: Element) => child.tagName === current!.tagName
              );
              if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(current) + 1})`;
            }
            parts.unshift(part);
            current = parent;
          }
          return parts.join(" > ");
        }
      })
    ]);

    return {
      activeTab: this.context!.pages().indexOf(page),
      tabs: await this.tabs(),
      page: {
        title,
        url: page.url(),
        ...pageData
      }
    };
  }

  private async click(params: Record<string, unknown>) {
    const parsed = ClickSchema.parse(params);
    const page = await this.ensurePage();
    const matcher = parsed.exact ? { exact: true } : undefined;

    if (parsed.role) {
      await page.getByRole(parsed.role, { name: parsed.text, ...matcher }).first().click({ timeout: 7000 });
    } else {
      await page.getByText(parsed.text, matcher).first().click({ timeout: 7000 });
    }

    await page.waitForLoadState("domcontentloaded").catch(() => undefined);
    return this.snapshot();
  }

  private async extract() {
    const snapshot = await this.snapshot();
    return {
      activeTab: snapshot.activeTab,
      tabs: snapshot.tabs,
      page: {
        title: snapshot.page.title,
        url: snapshot.page.url,
        text: snapshot.page.text,
        elements: snapshot.page.elements,
        videos: snapshot.page.videos
      }
    };
  }

  private async clickRef(params: Record<string, unknown>) {
    const parsed = RefSchema.parse(params);
    const page = await this.ensurePage();
    const clicked = await page.evaluate((ref) => {
      const index = Number(ref.slice(1));
      const element = interactiveElements()[index] as HTMLElement | undefined;
      if (!element) return false;
      element.scrollIntoView({ block: "center", inline: "center" });
      element.click();
      return true;

      function visible(element: Element) {
        const style = window.getComputedStyle(element);
        const rect = element.getBoundingClientRect();
        return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
      }

      function interactiveElements() {
        return Array.from(
          document.querySelectorAll(
            [
              "a",
              "button",
              "[role='button']",
              "[role='link']",
              "[role='tab']",
              "[role='menuitem']",
              "input",
              "textarea",
              "select",
              "[contenteditable='true']",
              "[tabindex]:not([tabindex='-1'])",
              "video"
            ].join(", ")
          )
        ).filter(visible);
      }
    }, parsed.ref);

    if (!clicked) {
      throw new SkillError("ELEMENT_REF_NOT_FOUND", `Could not find element ref ${parsed.ref}`);
    }

    await page.waitForLoadState("domcontentloaded").catch(() => undefined);
    return this.snapshot();
  }

  private async clickSelector(params: Record<string, unknown>) {
    const parsed = SelectorSchema.parse(params);
    const page = await this.ensurePage();
    await page.locator(parsed.selector).first().click({ timeout: 7000 });
    await page.waitForLoadState("domcontentloaded").catch(() => undefined);
    return this.snapshot();
  }

  private async type(params: Record<string, unknown>) {
    const parsed = TypeSchema.parse(params);
    const page = await this.ensurePage();
    const target = page
      .getByLabel(parsed.target)
      .or(page.getByPlaceholder(parsed.target))
      .or(page.locator(`[name="${cssString(parsed.target)}"]`))
      .first();

    await target.waitFor({ state: "visible", timeout: 7000 });
    if (parsed.clear) {
      await target.fill("");
    }
    await target.fill(parsed.text);
    if (parsed.submit) {
      await target.press("Enter");
      await page.waitForLoadState("domcontentloaded").catch(() => undefined);
    }
    return this.snapshot();
  }

  private async typeSelector(params: Record<string, unknown>) {
    const parsed = SelectorSchema.extend({ text: z.string() }).parse(params);
    const page = await this.ensurePage();
    const target = page.locator(parsed.selector).first();
    await target.waitFor({ state: "visible", timeout: 7000 });
    if (parsed.clear) {
      await target.fill("");
    }
    await target.fill(parsed.text);
    if (parsed.submit) {
      await target.press("Enter");
      await page.waitForLoadState("domcontentloaded").catch(() => undefined);
    }
    return this.snapshot();
  }

  private async typeRef(params: Record<string, unknown>) {
    const parsed = RefSchema.extend({ text: z.string() }).parse(params);
    const page = await this.ensurePage();
    const typed = await page.evaluate(({ ref, text, clear }) => {
      const index = Number(ref.slice(1));
      const element = interactiveElements()[index] as HTMLInputElement | HTMLTextAreaElement | HTMLElement | undefined;
      if (!element) return false;
      element.scrollIntoView({ block: "center", inline: "center" });
      element.focus();

      if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
        if (clear) element.value = "";
        element.value = clear ? text : `${element.value}${text}`;
        element.dispatchEvent(new InputEvent("input", { bubbles: true, data: text }));
        element.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }

      if (element.isContentEditable) {
        if (clear) element.textContent = "";
        element.textContent = clear ? text : `${element.textContent ?? ""}${text}`;
        element.dispatchEvent(new InputEvent("input", { bubbles: true, data: text }));
        return true;
      }

      return false;

      function visible(element: Element) {
        const style = window.getComputedStyle(element);
        const rect = element.getBoundingClientRect();
        return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
      }

      function interactiveElements() {
        return Array.from(
          document.querySelectorAll(
            [
              "a",
              "button",
              "[role='button']",
              "[role='link']",
              "[role='tab']",
              "[role='menuitem']",
              "input",
              "textarea",
              "select",
              "[contenteditable='true']",
              "[tabindex]:not([tabindex='-1'])",
              "video"
            ].join(", ")
          )
        ).filter(visible);
      }
    }, parsed);

    if (!typed) {
      throw new SkillError("ELEMENT_REF_NOT_TYPEABLE", `Could not type into element ref ${parsed.ref}`);
    }

    if (parsed.submit) {
      await page.keyboard.press("Enter");
      await page.waitForLoadState("domcontentloaded").catch(() => undefined);
    }

    return this.snapshot();
  }

  private async pressKey(params: Record<string, unknown>) {
    const parsed = KeySchema.parse(params);
    const page = await this.ensurePage();
    await page.keyboard.press(parsed.key);
    return this.snapshot();
  }

  private async scroll(params: Record<string, unknown>) {
    const parsed = ScrollSchema.parse(params);
    const page = await this.ensurePage();
    if (parsed.direction === "top") {
      await page.evaluate(() => window.scrollTo({ top: 0, behavior: "instant" }));
    } else if (parsed.direction === "bottom") {
      await page.evaluate(() => window.scrollTo({ top: document.body.scrollHeight, behavior: "instant" }));
    } else {
      const pixels = parsed.amount <= 30 ? parsed.amount * 700 : parsed.amount;
      const delta = parsed.direction === "down" ? pixels : -pixels;
      await page.mouse.wheel(0, delta);
    }
    return this.snapshot();
  }

  private async videoControl(params: Record<string, unknown>) {
    const parsed = VideoSchema.parse(params);
    const page = await this.ensurePage();
    const result = await page.evaluate(({ command, seconds }) => {
      const video = document.querySelector("video");
      if (!video) {
        return { found: false };
      }

      if (command === "play") void video.play();
      if (command === "pause") video.pause();
      if (command === "toggle") video.paused ? void video.play() : video.pause();
      if (command === "seek" && typeof seconds === "number") video.currentTime = seconds;

      return {
        found: true,
        paused: video.paused,
        currentTime: video.currentTime,
        duration: Number.isFinite(video.duration) ? video.duration : null
      };
    }, parsed);

    return { video: result, snapshot: await this.snapshot() };
  }

  private async youtubeComment(params: Record<string, unknown>) {
    const parsed = YouTubeCommentSchema.parse(params);
    const page = await this.ensurePage();

    if (!page.url().includes("youtube.com/watch")) {
      throw new SkillError("NOT_YOUTUBE_WATCH_PAGE", "youtube.comment works on a YouTube video page.");
    }

    const foundComments = await this.scrollToYouTubeComments(page);
    if (!foundComments) {
      throw new SkillError("YOUTUBE_COMMENTS_NOT_FOUND", "Could not find the YouTube comments section.");
    }

    const opened = await this.openYouTubeCommentBox(page);
    if (!opened) {
      throw new SkillError("YOUTUBE_COMMENT_BOX_NOT_FOUND", "Could not open the YouTube comment box. Comments may be disabled or not loaded.");
    }

    await page.keyboard.insertText(parsed.text);

    if (parsed.submit) {
      const submitted = await page.evaluate(() => {
        const candidates = Array.from(document.querySelectorAll<HTMLElement>(
          [
            "ytd-comment-simplebox-renderer #submit-button button",
            "ytd-commentbox #submit-button button",
            "#submit-button button",
            "button[aria-label*='Comment']",
            "button[aria-label*='comment']"
          ].join(", ")
        ));
        const button = candidates.find((element) => {
          const rect = element.getBoundingClientRect();
          const disabled = element.hasAttribute("disabled") || element.getAttribute("aria-disabled") === "true";
          return rect.width > 0 && rect.height > 0 && !disabled;
        });
        button?.click();
        return Boolean(button);
      });

      if (!submitted) {
        await page.keyboard.press("Control+Enter").catch(() => undefined);
      }
      await page.waitForTimeout(1200);
    }

    return this.snapshot();
  }

  private async scrollToYouTubeComments(page: Page): Promise<boolean> {
    for (let attempt = 0; attempt < 8; attempt++) {
      const found = await page.evaluate(() => {
        const comments = document.querySelector<HTMLElement>("ytd-comments#comments, ytd-comments");
        if (!comments) return false;
        comments.scrollIntoView({ block: "start", behavior: "instant" });
        return true;
      });
      if (found) {
        await page.waitForTimeout(1000);
        return true;
      }
      await page.mouse.wheel(0, Math.max(page.viewportSize()?.height ?? 900, 900));
      await page.waitForTimeout(700);
    }
    return false;
  }

  private async openYouTubeCommentBox(page: Page): Promise<boolean> {
    for (let attempt = 0; attempt < 5; attempt++) {
      const opened = await page.evaluate(() => {
        const visible = (element: HTMLElement) => {
          const rect = element.getBoundingClientRect();
          const style = window.getComputedStyle(element);
          return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
        };

        const editor = Array.from(document.querySelectorAll<HTMLElement>("#contenteditable-root[contenteditable='true']"))
          .find(visible);
        if (editor) {
          editor.scrollIntoView({ block: "center", behavior: "instant" });
          editor.focus();
          editor.click();
          return true;
        }

        const placeholders = Array.from(document.querySelectorAll<HTMLElement>(
          [
            "ytd-comment-simplebox-renderer #placeholder-area",
            "ytd-comment-simplebox-renderer #simplebox-placeholder",
            "ytd-comments #placeholder-area",
            "ytd-comments #simplebox-placeholder",
            "[aria-label*='comment']",
            "[aria-label*='Comment']"
          ].join(", ")
        ));
        const target = placeholders.find((element) => visible(element) && (element.textContent ?? element.getAttribute("aria-label") ?? "").toLowerCase().includes("comment"));
        if (!target) return false;
        target.scrollIntoView({ block: "center", behavior: "instant" });
        target.click();
        return true;
      });

      await page.waitForTimeout(700);

      const focusedEditor = await page.evaluate(() => {
        const active = document.activeElement as HTMLElement | null;
        if (active?.isContentEditable) return true;
        const editor = Array.from(document.querySelectorAll<HTMLElement>("#contenteditable-root[contenteditable='true']"))
          .find((element) => {
            const rect = element.getBoundingClientRect();
            return rect.width > 0 && rect.height > 0;
          });
        if (!editor) return false;
        editor.focus();
        editor.click();
        return true;
      });

      if (opened && focusedEditor) return true;
      await page.mouse.wheel(0, 450);
      await page.waitForTimeout(500);
    }

    return false;
  }

  private async tabs() {
    return Promise.all(
      this.context!.pages().map(async (page, index) => ({
        index,
        title: await page.title().catch(() => ""),
        url: page.url()
      }))
    );
  }

  private async contextOrOpen(): Promise<BrowserContext> {
    if (!this.context) {
      await this.open({ headless: false });
    }
    return this.context!;
  }
}

function normalizeUrl(input: string): string {
  if (/^(https?:\/\/|about:|chrome:|edge:|file:\/\/)/i.test(input)) {
    return input;
  }
  return `https://${input}`;
}

function cssString(input: string): string {
  return input.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

function expandEnvPath(path: string): string {
  const expanded = path.replace(/%([^%]+)%/g, (_, name: string) => process.env[name] ?? `%${name}%`);
  return isAbsolute(expanded) ? expanded : resolve(process.cwd(), expanded);
}

async function connectToCdp(endpoint: string): Promise<Browser> {
  return chromium.connectOverCDP(endpoint);
}

function launchChromeForCdp(port: number): void {
  const chromePath = findChromePath();
  const userDataDir = expandEnvPath(process.env.JARVIS_CHROME_USER_DATA_DIR ?? "%LOCALAPPDATA%\\Google\\Chrome\\User Data");
  const profile = process.env.JARVIS_CHROME_PROFILE ?? "Default";

  const child = spawn(
    chromePath,
    [
      `--remote-debugging-port=${port}`,
      `--user-data-dir=${userDataDir}`,
      `--profile-directory=${profile}`,
      "--no-first-run",
      "--no-default-browser-check",
      "about:blank"
    ],
    {
      detached: true,
      stdio: "ignore",
      windowsHide: false
    }
  );

  child.unref();
}

function findChromePath(): string {
  const configured = process.env.JARVIS_CHROME_EXE ? expandEnvPath(process.env.JARVIS_CHROME_EXE) : undefined;
  const candidates = [
    configured,
    "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe",
    "%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe",
    "%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe"
  ]
    .filter((candidate): candidate is string => Boolean(candidate))
    .map(expandEnvPath);

  const found = candidates.find((candidate) => existsSync(candidate));
  if (!found) {
    throw new SkillError("CHROME_NOT_FOUND", "Could not find installed Chrome. Set JARVIS_CHROME_EXE in .env.");
  }

  return found;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
