import { z } from "zod";

export const CommandSchema = z.object({
  id: z.string().min(1),
  action: z.string().min(1),
  params: z.record(z.unknown()).default({})
});

export type SkillCommand = z.infer<typeof CommandSchema>;

export type SkillResult =
  | {
      id: string;
      ok: true;
      action: string;
      data: unknown;
    }
  | {
      id: string;
      ok: false;
      action: string;
      error: {
        code: string;
        message: string;
        details?: unknown;
      };
    };

export class SkillError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly details?: unknown
  ) {
    super(message);
  }
}

export function ok(id: string, action: string, data: unknown): SkillResult {
  return { id, ok: true, action, data };
}

export function fail(id: string, action: string, error: unknown): SkillResult {
  if (error instanceof SkillError) {
    return {
      id,
      ok: false,
      action,
      error: {
        code: error.code,
        message: error.message,
        details: error.details
      }
    };
  }

  const message = error instanceof Error ? error.message : String(error);
  return {
    id,
    ok: false,
    action,
    error: {
      code: "INTERNAL_ERROR",
      message
    }
  };
}
