import { loadEnv } from "./config.js";

loadEnv();

const apiKey = process.env.GEMINI_API_KEY;

if (!apiKey) {
  console.error("GEMINI_API_KEY missing hai. .env me key add karo.");
  process.exit(1);
}

const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`);
const data = (await response.json()) as {
  models?: Array<{
    name: string;
    displayName?: string;
    supportedGenerationMethods?: string[];
  }>;
  error?: { message?: string };
};

if (!response.ok) {
  console.error(data.error?.message ?? `Model list failed with ${response.status}`);
  process.exit(1);
}

const models = data.models
  ?.filter((model) => model.supportedGenerationMethods?.includes("generateContent"))
  .map((model) => ({
    name: model.name.replace(/^models\//, ""),
    displayName: model.displayName ?? ""
  }));

console.log(JSON.stringify(models ?? [], null, 2));
