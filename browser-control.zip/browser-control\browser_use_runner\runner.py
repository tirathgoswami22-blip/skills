from __future__ import annotations

import argparse
import asyncio
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from dotenv import load_dotenv


ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")

os.environ.setdefault("BROWSER_USE_CONFIG_DIR", str(ROOT / ".jarvis" / "browser-use"))
os.environ.setdefault("ANONYMIZED_TELEMETRY", "false")


def _json_error(message: str, *, code: str = "BROWSER_USE_FAILED", details: Any = None) -> int:
    print(json.dumps({"ok": False, "code": code, "error": message, "details": details}, ensure_ascii=False))
    return 1


def _chrome_exe() -> str | None:
    configured = os.environ.get("JARVIS_CHROME_EXE")
    candidates = [
        configured,
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return candidate
    return None


def _is_cdp_ready(port: str) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/json/version", timeout=1.5) as response:
            return response.status == 200
    except (OSError, urllib.error.URLError):
        return False


def _launch_debug_chrome(port: str, user_data_dir: str, profile_directory: str) -> None:
    chrome = _chrome_exe()
    if not chrome:
        raise RuntimeError("Chrome exe not found. Set JARVIS_CHROME_EXE in .env.")

    Path(user_data_dir).mkdir(parents=True, exist_ok=True)
    args = [
        chrome,
        f"--remote-debugging-port={port}",
        f"--user-data-dir={user_data_dir}",
        f"--profile-directory={profile_directory}",
        "--no-first-run",
        "--no-default-browser-check",
        "about:blank",
    ]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=subprocess.DETACHED_PROCESS)

    for _ in range(20):
        if _is_cdp_ready(port):
            return
        time.sleep(0.5)
    raise RuntimeError(f"Chrome debug port {port} did not become ready.")


def _workspace_path(value: str | None, default: str) -> str:
    raw = value or default
    expanded = os.path.expandvars(raw)
    path = Path(expanded)
    if not path.is_absolute():
        path = ROOT / path
    path.mkdir(parents=True, exist_ok=True)
    return str(path)


async def _run(args: argparse.Namespace) -> dict[str, Any]:
    from browser_use import Agent, BrowserProfile, BrowserSession
    from browser_use.llm.google.chat import ChatGoogle

    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY missing hai.")

    model = os.environ.get("JARVIS_BROWSER_USE_MODEL") or os.environ.get("GEMINI_MODEL") or "gemini-2.5-flash"
    fallback_models = [
        item.strip()
        for item in (
            os.environ.get("JARVIS_BROWSER_USE_FALLBACK_MODELS")
            or os.environ.get("GEMINI_FALLBACK_MODELS")
            or "gemini-2.0-flash-lite,gemini-flash-lite-latest,gemini-2.0-flash"
        ).split(",")
        if item.strip() and item.strip() != model
    ]
    llm = ChatGoogle(model=model, api_key=api_key, temperature=0.1)
    fallback_llm = ChatGoogle(model=fallback_models[0], api_key=api_key, temperature=0.1) if fallback_models else None

    browser_mode = os.environ.get("JARVIS_BROWSER_USE_MODE") or os.environ.get("JARVIS_CHROME_MODE") or "cdp"
    port = os.environ.get("JARVIS_CHROME_DEBUG_PORT", "9222")
    chrome_exe = _chrome_exe()
    user_data_dir = _workspace_path(
        os.environ.get("JARVIS_BROWSER_USE_USER_DATA_DIR") or os.environ.get("JARVIS_CHROME_USER_DATA_DIR"),
        ".jarvis/chrome-profile",
    )
    profile_directory = os.environ.get("JARVIS_BROWSER_USE_PROFILE") or os.environ.get("JARVIS_CHROME_PROFILE") or "Default"

    profile_kwargs: dict[str, Any] = {
        "headless": False,
        "channel": os.environ.get("JARVIS_CHROME_CHANNEL", "chrome"),
        "profile_directory": profile_directory,
        "keep_alive": True,
        "wait_between_actions": float(os.environ.get("JARVIS_BROWSER_USE_ACTION_DELAY", "0.08")),
        "highlight_elements": True,
        "window_size": {"width": int(os.environ.get("JARVIS_BROWSER_USE_WIDTH", "1280")), "height": int(os.environ.get("JARVIS_BROWSER_USE_HEIGHT", "900"))},
    }
    if chrome_exe:
        profile_kwargs["executable_path"] = chrome_exe

    session_kwargs: dict[str, Any] = {}

    if browser_mode.lower() == "cdp":
        cdp_url = f"http://127.0.0.1:{port}"
        if not _is_cdp_ready(port):
            _launch_debug_chrome(port, user_data_dir, profile_directory)
        profile_kwargs["cdp_url"] = cdp_url
        session_kwargs["cdp_url"] = cdp_url
    else:
        profile_kwargs["user_data_dir"] = user_data_dir

    browser_profile = BrowserProfile(**profile_kwargs)
    browser_session = BrowserSession(browser_profile=browser_profile, **session_kwargs)

    system_extension = (
        "You are a browser-control specialist inside Jarvis. "
        "Use the visible browser carefully. Prefer real UI interactions when needed. "
        "If login, OTP, payment, password, or captcha is required, stop and say the user must handle it manually. "
        "Do not delete, purchase, upload, or post publicly unless the user's task explicitly asked for it. "
        "For messaging, commenting, posting, or form submission tasks: perform the final send/submit action at most once. "
        "Before sending, check the recent visible conversation/comments; if the exact requested text already appears as the newest outgoing/user-created item, treat the task as complete. "
        "After one successful send/comment/post/submit, immediately finish. Never send the same text repeatedly."
    )
    if os.environ.get("JARVIS_LANGUAGE", "hi").lower().startswith("hi"):
        system_extension += " All status and final responses must be in natural energetic Hindi/Hinglish. Address the user as boss. Never respond in English unless the user explicitly asks for English."
    else:
        system_extension += " All status and final responses must be in English."

    agent = Agent(
        task=args.task,
        llm=llm,
        browser_session=browser_session,
        use_vision=True,
        max_actions_per_step=int(os.environ.get("JARVIS_BROWSER_USE_MAX_ACTIONS_PER_STEP", "4")),
        max_failures=int(os.environ.get("JARVIS_BROWSER_USE_MAX_FAILURES", "2")),
        use_thinking=os.environ.get("JARVIS_BROWSER_USE_THINKING", "off").lower() == "on",
        use_judge=os.environ.get("JARVIS_BROWSER_USE_JUDGE", "off").lower() == "on",
        flash_mode=os.environ.get("JARVIS_BROWSER_USE_FLASH_MODE", "on").lower() == "on",
        enable_planning=os.environ.get("JARVIS_BROWSER_USE_PLANNING", "off").lower() == "on",
        loop_detection_enabled=True,
        loop_detection_window=int(os.environ.get("JARVIS_BROWSER_USE_LOOP_WINDOW", "4")),
        message_compaction=False,
        fallback_llm=fallback_llm,
        extend_system_message=system_extension,
        source="jarvis-browser-use",
    )
    history = await agent.run(max_steps=args.max_steps)

    try:
        await browser_session.stop()
    except Exception:
        pass

    return {
        "ok": True,
        "engine": "browser-use",
        "mode": browser_mode,
        "model": model,
        "fallbackModel": fallback_models[0] if fallback_models else None,
        "steps": history.number_of_steps(),
        "done": history.is_done(),
        "successful": history.is_successful(),
        "finalResult": history.final_result(),
        "urls": history.urls(),
        "errors": history.errors(),
        "actions": history.action_names(),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Jarvis browser-use runner")
    parser.add_argument("--task", required=True)
    parser.add_argument("--max-steps", type=int, default=int(os.environ.get("JARVIS_BROWSER_USE_MAX_STEPS", "10")))
    args = parser.parse_args()

    try:
        result = asyncio.run(_run(args))
    except Exception as error:
        return _json_error(str(error), details=type(error).__name__)

    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
