$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $root

if (-not (Test-Path -LiteralPath ".venv-parser")) {
  python -m venv .venv-parser
}

& ".\.venv-parser\Scripts\python.exe" -m pip install -r visual_parser\requirements.txt
& ".\.venv-parser\Scripts\python.exe" visual_parser\server.py
