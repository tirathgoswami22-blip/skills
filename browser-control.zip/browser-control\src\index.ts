import { createInterface } from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { BrowserSkill } from "./browserSkill.js";
import { DesktopSkill } from "./desktopSkill.js";
import { CommandSchema, fail, ok } from "./protocol.js";

const skill = new BrowserSkill();
const desktop = new DesktopSkill();
const rl = createInterface({ input });

for await (const line of rl) {
  const raw = line.trim();
  if (!raw) continue;

  let id = "unknown";
  let action = "unknown";

  try {
    const parsedJson: unknown = JSON.parse(raw);
    const command = CommandSchema.parse(parsedJson);
    id = command.id;
    action = command.action;
    const data = command.action.startsWith("desktop.")
      ? await desktop.execute(command.action, command.params)
      : await skill.execute(command.action, command.params);
    output.write(`${JSON.stringify(ok(command.id, command.action, data))}\n`);
  } catch (error) {
    output.write(`${JSON.stringify(fail(id, action, error))}\n`);
  }
}
