import { SkillError } from "./protocol.js";

export type VisualParserResult = {
  mode: "visual_parser";
  image: { width: number; height: number };
  elements: Array<{
    id: string;
    source: string;
    kind: string;
    text: string;
    bbox: [number, number, number, number];
    center: { x: number; y: number };
    confidence: number;
  }>;
};

export class VisualParserClient {
  constructor(private readonly url: string) {}

  async parse(screenshotBase64: string): Promise<VisualParserResult> {
    const response = await fetch(this.url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ screenshotBase64 })
    });

    if (!response.ok) {
      throw new SkillError("VISUAL_PARSER_FAILED", `Visual parser failed with ${response.status}`);
    }

    return (await response.json()) as VisualParserResult;
  }
}
