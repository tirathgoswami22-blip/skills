# Jarvis Browser Control Skill

This is the first Jarvis skill: a controlled browser automation tunnel.

Skill name: `browser-control`

Installable skill copy: `skills/browser-control`

The AI brain, such as Gemini, should not directly press random buttons. It should call this skill with structured JSON commands. The skill opens or attaches to Chrome/Chromium, manages tabs and windows, reads page structure, and performs browser actions.

## What It Can Do

- Open a browser window.
- Open, close, list, and switch tabs.
- Navigate to URLs.
- Search the web.
- Read a page snapshot: title, URL, visible text, links, buttons, inputs, and video status.
- Click links/buttons by text.
- Type into inputs by label, placeholder, name, or nearby text.
- Press keys.
- Scroll.
- Play, pause, and seek videos.
- Return structured feedback after every action.

## Install

```powershell
npm install
npm run build
```

## Skill Install Mode

Jarvis can keep skills outside the core app. The Browser Control skill name is `browser-control`.

Local installable copy for GitHub publishing:

```text
skills/browser-control
```

Later, when you publish that folder to GitHub, run:

```powershell
npm.cmd run skill:install
```

The installer asks whether to install `browser-control`, asks for the GitHub repo URL, then clones it into:

```text
.jarvis\skills\browser-control
```

Secrets are not included in the skill folder. `GEMINI_API_KEY` is intentionally not committed; Jarvis asks for it on first run and saves it to `.env`.

Playwright may ask to install browsers:

```powershell
npx playwright install chromium
```

## Run

```powershell
npm start
```

The process reads newline-delimited JSON commands from stdin and writes newline-delimited JSON results to stdout.

## Run Jarvis Browser Mode

Create `.env`:

```text
GEMINI_API_KEY=your_google_ai_studio_key
GEMINI_MODEL=gemini-2.5-flash
GEMINI_FALLBACK_MODELS=gemini-2.0-flash-lite,gemini-flash-lite-latest,gemini-2.0-flash
JARVIS_RISKY_ACTIONS=allow
JARVIS_CHROME_MODE=cdp
JARVIS_CHROME_CHANNEL=chrome
JARVIS_CHROME_DEBUG_PORT=9222
JARVIS_CHROME_USER_DATA_DIR=.jarvis\chrome-profile
JARVIS_CHROME_PROFILE=Default
JARVIS_DESKTOP_FALLBACK=on
JARVIS_VISUAL_PARSER=on
JARVIS_VISUAL_PARSER_URL=http://127.0.0.1:7860/parse
JARVIS_BROWSER_USE=on
JARVIS_BROWSER_USE_MODE=cdp
JARVIS_BROWSER_USE_MODEL=gemini-2.5-flash
JARVIS_BROWSER_USE_MAX_STEPS=8
JARVIS_BROWSER_USE_MAX_ACTIONS_PER_STEP=8
JARVIS_BROWSER_USE_ACTION_DELAY=0.02
JARVIS_BROWSER_USE_FLASH_MODE=on
JARVIS_BROWSER_USE_THINKING=off
JARVIS_BROWSER_USE_JUDGE=off
JARVIS_BROWSER_USE_PLANNING=off
BROWSER_USE_CONFIG_DIR=.jarvis\browser-use
```

Then:

```powershell
npm run build
npm run jarvis
```

Jarvis browser mode takes natural-language goals, asks Gemini for one safe next action, executes it through the browser skill, reads the new snapshot, and repeats.

## Run Jarvis Voice UI

```powershell
npm.cmd run web:ps
```

This starts the visual parser, opens `http://127.0.0.1:8787`, and serves a local browser UI with mic input, command text input, animated Jarvis orb, and browser text-to-speech output.

For signed-in Jarvis Chrome, run `npm.cmd run chrome:debug` first. It opens normal installed Chrome with a dedicated profile at `.jarvis\chrome-profile` and a local debug port. Log in there once, then run `npm.cmd run jarvis`; Jarvis attaches to that already-open signed-in Chrome without using the Google-blocked automation login flow.

The Chrome login/session is stored in `.jarvis\chrome-profile`, so after one successful sign-in you should not need to sign in again unless Google expires the session.

`JARVIS_VISUAL_PARSER_URL` points to a local YOLO/OmniParser-style service that converts screenshots into text regions/buttons. Start it with:

```powershell
npm.cmd run visual:parser
```

When `JARVIS_VISUAL_PARSER=on`, Jarvis sends screenshots to the parser and gives Gemini parsed JSON boxes instead of the raw image.

Desktop fallback screenshots/clicks are scoped to the visible Chrome window. Parser coordinates are window-relative, and Jarvis refuses window-relative clicks outside Chrome bounds.

Jarvis also has a primary `browser-use` tunnel for modern web-app flows. It is used as `browserUse.run` first, while DOM, visual parser, and desktop actions remain as fallback/follow-up tools. Install/update it with:

```powershell
python -m venv .venv-browser-use
.\.venv-browser-use\Scripts\python.exe -m pip install -r browser_use_runner\requirements.txt
```

In `JARVIS_BROWSER_USE_MODE=cdp`, browser-use attaches to the same debug Chrome session/profile as the rest of Jarvis. Current YOLO/visual-parser observations are injected into browser-use tasks as extra visual hints.

YOLO/Ultralytics is optional and can be installed later with:

```powershell
.\.venv-parser\Scripts\python.exe -m pip install -r visual_parser\requirements-yolo.txt
```

## Example

Input:

```json
{"id":"1","action":"browser.open","params":{"headless":false}}
```

Input:

```json
{"id":"2","action":"page.search","params":{"query":"lofi beats youtube"}}
```

Input:

```json
{"id":"3","action":"page.snapshot","params":{}}
```

## Skill Boundary

This skill controls the browser only. It does not own the AI brain, memory, voice, or app launcher. Those will be separate Jarvis layers.

Risky actions should be approved by a higher permission layer before this skill receives commands, especially login, payment, upload, deletion, or message sending.

See [docs/BROWSER_SKILL_CONTRACT.md](docs/BROWSER_SKILL_CONTRACT.md) for the full command contract.
