import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import { loadEnv, setEnvValue } from "./config.js";
import { JarvisCore } from "./jarvisCore.js";

loadEnv();

const port = Number(process.env.JARVIS_WEB_PORT ?? "8787");
let jarvis: JarvisCore | undefined;

const server = createServer(async (request, response) => {
  try {
    if (request.method === "GET" && request.url === "/") return html(response);
    if (request.method === "GET" && request.url === "/api/status") {
      return json(response, {
        ok: true,
        hasApiKey: Boolean(process.env.GEMINI_API_KEY),
        language: parseLanguage(process.env.JARVIS_LANGUAGE)
      });
    }
    if (request.method === "POST" && request.url === "/api/setup") return setup(request, response);
    if (request.method === "POST" && request.url === "/api/command") return command(request, response);
    if (request.method === "POST" && request.url === "/api/command-stream") return commandStream(request, response);
    response.writeHead(404).end("Not found");
  } catch (error) {
    json(response, { ok: false, error: error instanceof Error ? error.message : String(error) }, 500);
  }
});

server.listen(port, "127.0.0.1", () => {
  console.log(`Jarvis web UI ready: http://127.0.0.1:${port}`);
});

process.on("SIGINT", async () => {
  await jarvis?.close().catch(() => undefined);
  process.exit(0);
});

async function setup(request: IncomingMessage, response: ServerResponse) {
  const body = await readJson(request);
  const apiKey = typeof body.apiKey === "string" ? body.apiKey.trim() : "";
  if (!apiKey) return json(response, { ok: false, error: "API key missing" }, 400);
  const language = parseLanguage(typeof body.language === "string" ? body.language : process.env.JARVIS_LANGUAGE);
  setEnvValue("GEMINI_API_KEY", apiKey);
  setEnvValue("JARVIS_LANGUAGE", language);
  jarvis = new JarvisCore(apiKey);
  return json(response, { ok: true });
}

async function command(request: IncomingMessage, response: ServerResponse) {
  const body = await readJson(request);
  const text = typeof body.text === "string" ? body.text.trim() : "";
  if (!text) return json(response, { ok: false, error: "Command missing" }, 400);

  const core = ensureJarvis();
  const result = await core.runGoal(text);
  const reply = result.messages.at(-1) ?? (result.ok ? "Done." : "Task complete nahi hua.");
  return json(response, { ...result, reply });
}

async function commandStream(request: IncomingMessage, response: ServerResponse) {
  const body = await readJson(request);
  const text = typeof body.text === "string" ? body.text.trim() : "";
  if (!text) return json(response, { ok: false, error: "Command missing" }, 400);

  response.writeHead(200, {
    "content-type": "application/x-ndjson; charset=utf-8",
    "cache-control": "no-cache",
    connection: "keep-alive"
  });

  const write = (value: unknown) => {
    response.write(`${JSON.stringify(value)}\n`);
  };

  const core = ensureJarvis();
  const result = await core.runGoal(text, (event) => write({ event }));
  const reply = result.messages.at(-1) ?? (result.ok ? (parseLanguage(process.env.JARVIS_LANGUAGE) === "hi" ? "Ho gaya boss." : "Done.") : "Task complete nahi hua.");
  write({ final: { ...result, reply } });
  response.end();
}

function ensureJarvis(): JarvisCore {
  if (jarvis) return jarvis;
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) throw new Error("GEMINI_API_KEY missing");
  jarvis = new JarvisCore(apiKey);
  return jarvis;
}

function parseLanguage(value: string | undefined): "hi" | "en" {
  return value?.trim().toLowerCase().startsWith("en") ? "en" : "hi";
}

function readJson(request: IncomingMessage): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    let raw = "";
    request.on("data", (chunk) => {
      raw += String(chunk);
      if (raw.length > 2_000_000) {
        request.destroy();
        reject(new Error("Request too large"));
      }
    });
    request.on("end", () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        reject(new Error("Invalid JSON"));
      }
    });
    request.on("error", reject);
  });
}

function json(response: ServerResponse, value: unknown, status = 200) {
  const raw = JSON.stringify(value);
  response.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(raw)
  });
  response.end(raw);
}

function html(response: ServerResponse) {
  response.writeHead(200, { "content-type": "text/html; charset=utf-8" });
  response.end(`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Jarvis</title>
<style>
:root{color-scheme:dark;--bg:#07090d;--panel:#10151d;--text:#edf7ff;--muted:#8aa5b8;--cyan:#35d7ff;--gold:#ffd166;--pink:#ff5ea8;--green:#57e389}
*{box-sizing:border-box}body{margin:0;min-height:100vh;font-family:Inter,Segoe UI,Arial,sans-serif;background:radial-gradient(circle at 50% 18%,#163347 0,#0b1119 34%,#05070a 78%);color:var(--text);display:grid;place-items:center;overflow:hidden}
.shell{width:min(980px,100vw);height:min(820px,100vh);display:grid;grid-template-rows:auto 1fr auto;gap:18px;padding:28px}
.top{display:flex;justify-content:space-between;align-items:center}.brand{font-size:14px;letter-spacing:.22em;color:var(--muted);text-transform:uppercase}.state{font-size:13px;color:var(--green)}
.orb-wrap{display:grid;place-items:center;position:relative}.orb{width:min(54vmin,430px);aspect-ratio:1;border-radius:50%;position:relative;background:radial-gradient(circle at 50% 45%,rgba(60,215,255,.22),rgba(16,47,72,.16) 34%,rgba(4,10,17,.86) 63%,rgba(53,215,255,.18));box-shadow:0 0 70px rgba(53,215,255,.22),inset 0 0 45px rgba(53,215,255,.18);display:grid;place-items:center;transition:transform .22s ease,filter .22s ease}
.orb:before,.orb:after{content:"";position:absolute;inset:9%;border-radius:50%;border:1px solid rgba(53,215,255,.42);animation:spin 12s linear infinite}.orb:after{inset:22%;border-color:rgba(255,209,102,.35);animation-duration:8s;animation-direction:reverse}
.core{width:38%;aspect-ratio:1;border-radius:50%;background:radial-gradient(circle,#f6fdff 0,#64e2ff 24%,#176386 58%,#061019 76%);box-shadow:0 0 55px rgba(53,215,255,.9)}
.ring{position:absolute;border-radius:50%;border:2px solid transparent;border-top-color:var(--cyan);border-bottom-color:var(--pink);inset:3%;animation:spin 5.5s linear infinite}.ring.r2{inset:15%;border-top-color:var(--gold);border-bottom-color:var(--cyan);animation-duration:7s;animation-direction:reverse}
.orb.listening{transform:scale(1.07);filter:saturate(1.3)}.orb.listening .core{animation:pulse .9s ease-in-out infinite}.orb.thinking{animation:breathe 1.3s ease-in-out infinite}
@keyframes spin{to{transform:rotate(360deg)}}@keyframes pulse{50%{transform:scale(1.18);box-shadow:0 0 90px rgba(53,215,255,1)}}@keyframes breathe{50%{transform:scale(1.035)}}
.log{height:180px;overflow:auto;background:rgba(8,13,19,.72);border:1px solid rgba(120,215,255,.16);border-radius:14px;padding:14px;font-size:14px;line-height:1.45}.line{margin:0 0 8px}.you{color:#d4f6ff}.bot{color:#ffe7a3}.err{color:#ff9fba}
.controls{display:grid;grid-template-columns:auto 1fr auto;gap:12px;align-items:center}.btn{border:1px solid rgba(120,215,255,.24);background:#111a24;color:var(--text);height:48px;border-radius:999px;padding:0 18px;font-weight:700;cursor:pointer}.btn.icon{width:58px;padding:0;font-size:22px}.btn.active{background:#17384b;border-color:var(--cyan)}input{height:48px;border-radius:999px;border:1px solid rgba(120,215,255,.24);background:#0c121a;color:var(--text);padding:0 18px;font-size:15px;outline:none}
.setup{position:fixed;inset:0;background:rgba(3,6,10,.82);display:none;place-items:center;padding:20px}.setup.show{display:grid}.card{width:min(520px,100%);background:#101722;border:1px solid rgba(120,215,255,.24);border-radius:18px;padding:22px;box-shadow:0 20px 80px rgba(0,0,0,.45)}.card h1{margin:0 0 8px;font-size:24px}.card p{color:var(--muted);margin:0 0 18px}select{width:100%;height:44px;border-radius:12px;background:#0c121a;color:var(--text);border:1px solid rgba(120,215,255,.24);padding:0 12px;margin-top:10px}
</style>
</head>
<body>
<main class="shell">
  <div class="top"><div class="brand">Jarvis Voice Console</div><div id="state" class="state">Ready</div></div>
  <section class="orb-wrap"><div id="orb" class="orb"><div class="ring"></div><div class="ring r2"></div><div class="core"></div></div></section>
  <section id="log" class="log"></section>
  <form id="form" class="controls"><button id="mic" class="btn icon" type="button" title="Voice input">🎙</button><input id="command" autocomplete="off" placeholder="Command likho ya mic dabao..." /><button class="btn" type="submit">Send</button></form>
</main>
<div id="setup" class="setup"><div class="card"><h1>Jarvis Setup</h1><p>Gemini API key paste karo. Ye local .env me save hogi.</p><input id="apiKey" placeholder="Gemini API key" /><select id="language"><option value="hi">Hindi / Hinglish</option><option value="en">English</option></select><br/><br/><button id="saveKey" class="btn">Save & Start</button></div></div>
<script>
const state=document.getElementById('state'),orb=document.getElementById('orb'),log=document.getElementById('log'),form=document.getElementById('form'),input=document.getElementById('command'),mic=document.getElementById('mic'),setup=document.getElementById('setup');
let voices=[],femaleVoice=null,recognition=null,listening=false,language='hi',workingTimers=[];
function add(cls,text){const p=document.createElement('p');p.className='line '+cls;p.textContent=text;log.appendChild(p);log.scrollTop=log.scrollHeight}
function setState(text,mode){state.textContent=text;orb.classList.toggle('listening',mode==='listen');orb.classList.toggle('thinking',mode==='think')}
function loadVoices(){voices=speechSynthesis.getVoices();femaleVoice=voices.find(v=>/hi-IN|hi_|Hindi/i.test(v.lang+' '+v.name)&&/female|woman|hema|kalpana|swara|neural|natural/i.test(v.name))||voices.find(v=>/hi-IN|Hindi/i.test(v.lang+' '+v.name))||voices.find(v=>/female|zira|susan|hazel|aria|jenny|neural|woman/i.test(v.name))||voices.find(v=>/en-IN|en-US|en-GB/i.test(v.lang))||voices[0]}
speechSynthesis.onvoiceschanged=loadVoices;loadVoices();
function speak(text){if(!('speechSynthesis'in window)||!text)return; speechSynthesis.cancel(); const u=new SpeechSynthesisUtterance(text); u.voice=femaleVoice; u.lang=language==='hi'?'hi-IN':'en-IN'; u.rate=language==='hi'?.9:.96; u.pitch=1.04; u.volume=1; speechSynthesis.speak(u)}
async function status(){const r=await fetch('/api/status');const s=await r.json();language=s.language||'hi';document.getElementById('language').value=language;if(!s.hasApiKey)setup.classList.add('show')}
document.getElementById('saveKey').onclick=async()=>{const apiKey=document.getElementById('apiKey').value.trim();language=document.getElementById('language').value;if(!apiKey)return;const r=await fetch('/api/setup',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({apiKey,language})});const data=await r.json();if(data.ok){setup.classList.remove('show');add('bot',language==='hi'?'API key save ho gayi boss. Jarvis ready hai.':'API key saved. Jarvis is ready.')}else add('err',data.error||'Setup failed')};
function clearWorking(){for(const t of workingTimers)clearTimeout(t);workingTimers=[]}
async function send(text){text=text.trim();if(!text)return;add('you','You > '+text);input.value='';setState('Working','think');clearWorking();let spoke=false;const r=await fetch('/api/command-stream',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({text})});const reader=r.body.getReader();const decoder=new TextDecoder();let buffer='';while(true){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});const lines=buffer.split('\\n');buffer=lines.pop()||'';for(const line of lines){if(!line.trim())continue;const msg=JSON.parse(line);if(msg.event){const e=msg.event;if(e.type==='say'){add('bot','Jarvis > '+e.text);speak(e.text);spoke=true}else if(e.type==='error'){add('err','Jarvis > '+e.text)}else if(e.type==='action'){add('bot','Action > '+e.name)}}if(msg.final){const reply=msg.final.reply||msg.final.error||(language==='hi'?'Ho gaya boss.':'Done.');if(!spoke){add(msg.final.ok?'bot':'err','Jarvis > '+reply);speak(reply)}}}}setState('Ready','')}
form.onsubmit=e=>{e.preventDefault();send(input.value)};
function initMic(){const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SpeechRecognition){add('err','Speech recognition browser me available nahi hai. Chrome use karo.');return null}const rec=new SpeechRecognition();rec.lang=language==='hi'?'hi-IN':'en-IN';rec.interimResults=true;rec.continuous=false;rec.onstart=()=>{listening=true;mic.classList.add('active');setState('Listening','listen')};rec.onend=()=>{listening=false;mic.classList.remove('active');setState('Ready','')};rec.onerror=e=>{add('err','Mic error: '+e.error);setState('Ready','')};rec.onresult=e=>{let finalText='';let interim='';for(const res of e.results){if(res.isFinal)finalText+=res[0].transcript;else interim+=res[0].transcript}input.value=finalText||interim;if(finalText)send(finalText)};return rec}
mic.onclick=()=>{recognition=recognition||initMic();if(!recognition)return;if(listening)recognition.stop();else recognition.start()};
status().catch(()=>add('err','Status check failed'));
</script>
</body>
</html>`);
}
