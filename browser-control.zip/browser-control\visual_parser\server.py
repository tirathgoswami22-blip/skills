from __future__ import annotations

import base64
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from typing import Any

import cv2
import numpy as np
from PIL import Image

try:
    import pytesseract
except Exception:
    pytesseract = None

try:
    from ultralytics import YOLO
    YOLO_IMPORT_ERROR = None
except Exception:
    YOLO = None
    YOLO_IMPORT_ERROR = "ultralytics import failed"


MODEL = None
MODEL_ERROR = None
MODEL_PATH = os.environ.get("JARVIS_VISUAL_PARSER_MODEL", "yolov8s.pt")


def get_model():
    global MODEL
    global MODEL_ERROR
    if MODEL is not None:
        return MODEL
    if YOLO is None:
        MODEL_ERROR = YOLO_IMPORT_ERROR
        return None
    try:
        MODEL = YOLO(MODEL_PATH)
    except Exception as exc:
        MODEL_ERROR = str(exc)
        return None
    return MODEL


def parse_image(image_b64: str) -> dict[str, Any]:
    image = Image.open(BytesIO(base64.b64decode(image_b64))).convert("RGB")
    width, height = image.size
    frame = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)

    elements = []
    elements.extend(yolo_elements(frame))
    elements.extend(contour_elements(frame))
    elements.extend(ocr_elements(image))

    elements = merge_elements(elements, width, height)
    for index, element in enumerate(elements):
        element["id"] = f"v{index}"
        x, y, w, h = element["bbox"]
        element["center"] = {"x": int(x + w / 2), "y": int(y + h / 2)}

    return {
        "mode": "visual_parser",
        "image": {"width": width, "height": height},
        "elements": elements[:220],
    }


def yolo_elements(frame: np.ndarray) -> list[dict[str, Any]]:
    model = get_model()
    if model is None:
        return []
    results = model.predict(frame, verbose=False, conf=0.25)
    parsed = []
    for result in results:
        names = result.names
        for box in result.boxes:
            x1, y1, x2, y2 = [int(v) for v in box.xyxy[0].tolist()]
            cls = int(box.cls[0].item())
            parsed.append({
                "source": "yolo",
                "kind": str(names.get(cls, cls)),
                "text": "",
                "bbox": [x1, y1, max(1, x2 - x1), max(1, y2 - y1)],
                "confidence": float(box.conf[0].item()),
            })
    return parsed


def contour_elements(frame: np.ndarray) -> list[dict[str, Any]]:
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    parsed = []
    height, width = gray.shape
    area_min = max(120, int(width * height * 0.00005))
    area_max = int(width * height * 0.25)
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        area = w * h
        if area < area_min or area > area_max:
            continue
        if w < 12 or h < 8:
            continue
        aspect = w / max(1, h)
        if aspect > 30 or aspect < 0.03:
            continue
        parsed.append({
            "source": "opencv",
            "kind": "region",
            "text": "",
            "bbox": [int(x), int(y), int(w), int(h)],
            "confidence": 0.35,
        })
    return parsed


def ocr_elements(image: Image.Image) -> list[dict[str, Any]]:
    if pytesseract is None:
        return []
    try:
        data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
    except Exception:
        return []
    parsed = []
    for i, text in enumerate(data.get("text", [])):
        text = (text or "").strip()
        if not text:
            continue
        conf_raw = data.get("conf", ["-1"])[i]
        try:
            conf = float(conf_raw) / 100
        except Exception:
            conf = 0
        if conf < 0.35:
            continue
        parsed.append({
            "source": "ocr",
            "kind": "text",
            "text": text[:120],
            "bbox": [
                int(data["left"][i]),
                int(data["top"][i]),
                int(data["width"][i]),
                int(data["height"][i]),
            ],
            "confidence": conf,
        })
    return parsed


def merge_elements(elements: list[dict[str, Any]], width: int, height: int) -> list[dict[str, Any]]:
    filtered = []
    for element in sorted(elements, key=lambda item: (item["bbox"][1], item["bbox"][0], -item["confidence"])):
        x, y, w, h = element["bbox"]
        if x < 0 or y < 0 or x + w > width + 4 or y + h > height + 4:
            continue
        if any(iou(element["bbox"], existing["bbox"]) > 0.82 for existing in filtered):
            continue
        filtered.append(element)
    return filtered


def iou(a: list[int], b: list[int]) -> float:
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    x1 = max(ax, bx)
    y1 = max(ay, by)
    x2 = min(ax + aw, bx + bw)
    y2 = min(ay + ah, by + bh)
    inter = max(0, x2 - x1) * max(0, y2 - y1)
    union = aw * ah + bw * bh - inter
    return inter / union if union else 0


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path != "/health":
            self.send_error(404)
            return
        self.write_json({"ok": True, "modelLoaded": get_model() is not None, "modelPath": MODEL_PATH, "modelError": MODEL_ERROR})

    def do_POST(self):
        if self.path != "/parse":
            self.send_error(404)
            return
        length = int(self.headers.get("content-length", "0"))
        body = json.loads(self.rfile.read(length) or b"{}")
        image_b64 = body.get("screenshotBase64") or body.get("imageBase64")
        if not image_b64:
            self.send_error(400, "screenshotBase64 missing")
            return
        self.write_json(parse_image(image_b64))

    def write_json(self, value: dict[str, Any]):
        raw = json.dumps(value).encode("utf-8")
        self.send_response(200)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def log_message(self, format, *args):
        return


if __name__ == "__main__":
    port = int(os.environ.get("JARVIS_VISUAL_PARSER_PORT", "7860"))
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"Jarvis visual parser listening on http://127.0.0.1:{port}")
    server.serve_forever()
