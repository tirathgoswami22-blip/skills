$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $root

if (-not (Test-Path -LiteralPath "dist\webJarvis.js")) {
  npm.cmd run build
}

Start-Process -FilePath "powershell.exe" -ArgumentList @(
  "-NoExit",
  "-ExecutionPolicy",
  "Bypass",
  "-Command",
  "Set-Location -LiteralPath '$root'; npm.cmd run visual:parser"
) -WindowStyle Normal

Start-Process "http://127.0.0.1:8787"
npm.cmd run web
