import { existsSync } from "node:fs";
import { spawn } from "node:child_process";
import { resolve } from "node:path";
import { z } from "zod";
import { SkillError } from "./protocol.js";

const RunSchema = z.object({
  task: z.string().min(1),
  maxSteps: z.number().int().min(1).max(80).default(25)
});

export class WindowsUseSkill {
  private readonly root: string;

  constructor(root = resolve(process.cwd(), "..", "windows-control")) {
    this.root = resolve(process.env.JARVIS_WINDOWS_CONTROL_DIR ?? root);
  }

  isInstalled(): boolean {
    return existsSync(resolve(this.root, "windows_use_runner", "runner.py"));
  }

  async execute(action: string, params: Record<string, unknown>): Promise<unknown> {
    if (action !== "windowsUse.run") {
      throw new SkillError("UNKNOWN_WINDOWS_USE_ACTION", `Unknown Windows Use action: ${action}`);
    }
    if (!this.isInstalled()) {
      throw new SkillError("WINDOWS_CONTROL_NOT_INSTALLED", "windows-control skill installed nahi hai.");
    }

    const parsed = RunSchema.parse(params);
    const python = resolve(this.root, process.env.JARVIS_COMPUTER_USE_PYTHON ?? process.env.JARVIS_WINDOWS_USE_PYTHON ?? ".venv-computer-use\\Scripts\\python.exe");
    if (!existsSync(python)) {
      throw new SkillError("COMPUTER_USE_PYTHON_MISSING", "computer-use Python venv missing. Setup dobara chalao.", { python });
    }

    return runJsonProcess(python, [
      resolve(this.root, "windows_use_runner", "runner.py"),
      "--task",
      parsed.task,
      "--max-steps",
      String(parsed.maxSteps)
    ], this.root);
  }
}

function runJsonProcess(command: string, args: string[], cwd: string): Promise<unknown> {
  return new Promise((resolvePromise, reject) => {
    const child = spawn(command, args, {
      cwd,
      windowsHide: true,
      env: process.env
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => {
      stdout += String(chunk);
    });
    child.stderr.on("data", (chunk) => {
      stderr += String(chunk);
    });
    child.on("error", reject);
    child.on("exit", (code) => {
      const raw = stdout.trim().split(/\r?\n/).filter(Boolean).at(-1) ?? "";
      if (code !== 0) {
        reject(new SkillError("COMPUTER_USE_FAILED", stderr.trim() || raw || `computer-use exited with ${code}`));
        return;
      }
      try {
        resolvePromise(JSON.parse(raw));
      } catch {
        reject(new SkillError("COMPUTER_USE_BAD_JSON", "computer-use runner returned invalid JSON.", { stdout, stderr }));
      }
    });
  });
}
