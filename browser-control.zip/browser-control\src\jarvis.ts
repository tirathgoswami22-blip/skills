import { createInterface } from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { loadEnv, setEnvValue } from "./config.js";
import { JarvisCore } from "./jarvisCore.js";
import { selectedApiKey } from "./llmClient.js";

loadEnv();

const rl = createInterface({ input, output });
const apiKey = await ensureGeminiApiKey();
const jarvis = new JarvisCore(apiKey);

output.write("Jarvis browser mode ready. Command likho, exit ke liye 'exit'.\n");

for (;;) {
  const goal = await ask("\nYou > ");
  if (goal === undefined) break;
  const trimmedGoal = goal.trim();
  if (!trimmedGoal) continue;
  if (["exit", "quit"].includes(trimmedGoal.toLowerCase())) break;

  await jarvis.runGoal(trimmedGoal, (event) => {
    if (event.type === "say") output.write(`Jarvis > ${event.text}\n`);
    if (event.type === "error") output.write(`Jarvis > Error: ${event.text}\n`);
    if (event.type === "action") output.write(`Action > ${event.name} ${JSON.stringify(event.params)}\n`);
  });
}

await jarvis.close();
rl.close();

async function ask(question: string): Promise<string | undefined> {
  try {
    return await rl.question(question);
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ERR_USE_AFTER_CLOSE") return undefined;
    throw error;
  }
}

async function ensureGeminiApiKey(): Promise<string> {
  const provider = process.env.JARVIS_LLM_PROVIDER?.trim().toLowerCase().startsWith("groq") ? "groq" : "gemini";
  const existing = selectedApiKey()?.trim();
  if (existing) return existing;

  output.write(`Jarvis setup > ${provider === "groq" ? "GROQ_API_KEY" : "GEMINI_API_KEY"} missing hai. API key paste karo.\n`);
  const answer = await ask(`${provider === "groq" ? "Groq" : "Gemini"} API key > `);
  const apiKey = answer?.trim();
  if (!apiKey) {
    output.write("Jarvis setup > API key nahi mili. Jarvis band kar raha hoon.\n");
    process.exit(1);
  }

  setEnvValue(provider === "groq" ? "GROQ_API_KEY" : "GEMINI_API_KEY", apiKey);
  output.write("Jarvis setup > API key .env me save ho gayi.\n");
  return apiKey;
}
