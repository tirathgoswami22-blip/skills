# Browser Skill Contract

Jarvis should call this skill with one JSON object per line:

```json
{"id":"unique-id","action":"page.search","params":{"query":"openai docs"}}
```

The skill returns one JSON object per line:

```json
{"id":"unique-id","ok":true,"action":"page.search","data":{}}
```

Errors are structured:

```json
{"id":"unique-id","ok":false,"action":"page.click","error":{"code":"UNKNOWN_ACTION","message":"..."}}
```

## Important Design Rule

The AI brain should think in goals, but this skill only accepts browser actions. A higher Jarvis layer must decide permissions, break the goal into actions, and inspect `page.snapshot` after each step.

## Actions

## Desktop Fallback

If Chrome is already open normally and CDP/DOM mode is unavailable, Jarvis can still control Chrome with Windows focus, keyboard, and clipboard actions:

- `desktop.openChrome`
- `desktop.focusChrome`
- `desktop.addressBar`
- `desktop.type`
- `desktop.key`
- `desktop.click`
- `desktop.scroll`
- `desktop.screenshot`
- `desktop.closeTab`
- `desktop.wait`

Desktop fallback can open URLs, search from the address bar, paste text, press shortcuts, click Chrome-window coordinates, scroll with the mouse wheel, capture Chrome-window screenshots, and close tabs. It cannot inspect DOM buttons or read page structure; for that, CDP/browser mode is still best. With screenshots, Jarvis can use a computer-use style loop: look at the Chrome window, scroll/click coordinates inside that window, wait, look again.

Desktop screenshot and click safety:

- `desktop.screenshot` captures only the visible Chrome window, not the whole desktop.
- `desktop.click` defaults to `coordinateMode:"window"`.
- Window-relative clicks are refused if the coordinates are outside the Chrome window bounds.
- Use `coordinateMode:"screen"` only for explicit low-level debugging.

If `JARVIS_VISUAL_PARSER=on`, Chrome-window screenshots are sent to the local visual parser at `JARVIS_VISUAL_PARSER_URL`. The parser returns OmniParser-style window-relative elements with `id`, `kind`, `text`, `bbox`, `center`, and `confidence`, so the planner can click parsed element centers without asking Gemini to inspect the raw image.

### `browser.open`

Params:

```json
{"headless":false,"url":"https://google.com"}
```

Opens a browser if needed. Returns a snapshot.

### `browser.close`

Params:

```json
{}
```

Closes the browser process.

### `tab.new`

Params:

```json
{"url":"https://youtube.com"}
```

Opens a new tab and makes it active.

### `tab.close`

Params:

```json
{}
```

Closes the active tab and switches to another open tab.

### `tab.list`

Params:

```json
{}
```

Returns all known tabs with index, title, and URL.

### `tab.switch`

Params, choose one:

```json
{"index":1}
```

```json
{"titleIncludes":"YouTube"}
```

```json
{"urlIncludes":"youtube.com"}
```

Switches the active tab.

### `page.navigate`

Params:

```json
{"url":"https://example.com"}
```

Navigates the active tab.

### `page.search`

Params:

```json
{"query":"music for focus","engine":"google"}
```

Engine can be `google` or `youtube`.

### `page.snapshot`

Params:

```json
{}
```

Returns what Jarvis can use as eyes:

- active tab index
- tab list
- page title and URL
- visible page text
- visible links
- visible buttons
- visible inputs
- visible interactive elements with refs
- CSS selectors and HTML snippets for visible interactive elements
- video state

### `page.extract`

Params:

```json
{}
```

Returns the current page text plus visible interactive elements with refs, selectors, bounding boxes, and small HTML snippets. This is used when Jarvis needs deeper DOM understanding before choosing a control.

### `page.click`

Params:

```json
{"text":"Sign in","role":"button","exact":true}
```

Role is optional and can be `button`, `link`, `tab`, or `menuitem`.

### `page.clickRef`

Params:

```json
{"ref":"e31"}
```

Clicks an element returned by `page.snapshot.page.elements`. This is the preferred way for Jarvis to click because it avoids guessing selectors or exact text.

### `page.clickSelector`

Params:

```json
{"selector":"#submit-button"}
```

Clicks the first visible element matching a CSS selector from `page.extract` or `page.snapshot`.

### `page.type`

Params:

```json
{"target":"Search","text":"lofi beats","submit":true,"clear":true}
```

The target can match a label, placeholder, or input name.

### `page.typeRef`

Params:

```json
{"ref":"e4","text":"techno gamerz","submit":true,"clear":true}
```

Types into an input/contenteditable element returned by `page.snapshot.page.elements`.

### `page.typeSelector`

Params:

```json
{"selector":"input[name=\"search_query\"]","text":"gamer fleet smp","submit":true,"clear":true}
```

Types into the first visible input matching a CSS selector from `page.extract` or `page.snapshot`.

### `page.key`

Params:

```json
{"key":"Control+L"}
```

Uses Playwright keyboard names.

### `page.scroll`

Params:

```json
{"direction":"down","amount":650}
```

Direction can be `up`, `down`, `top`, or `bottom`.

### `video.control`

Params:

```json
{"command":"play"}
```

Command can be `play`, `pause`, `toggle`, or `seek`. For seek:

```json
{"command":"seek","seconds":60}
```

### `youtube.comment`

Params:

```json
{"text":"nice video","submit":true}
```

Posts a comment on the active YouTube watch page using YouTube's custom comment renderer. Use this instead of generic `page.type` for the `Add a comment...` box.

## Permission Layer Notes

This skill can click and type, so it is powerful. Jarvis should ask the user before:

- logging into an account
- submitting forms with personal data
- sending messages
- paying or checking out
- uploading/downloading files
- changing account settings
- deleting anything

## Next Engineering Step

The next layer should be a Jarvis planner that converts a user sentence into safe skill calls:

1. Call `page.snapshot`.
2. Decide the next browser command.
3. Execute it.
4. Inspect the new snapshot.
5. Repeat until the browser goal is done or permission is needed.
