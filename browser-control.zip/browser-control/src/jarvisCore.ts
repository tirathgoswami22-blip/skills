import { BrowserSkill } from "./browserSkill.js";
import { BrowserUseSkill } from "./browserUseSkill.js";
import { loadEnv } from "./config.js";
import { DesktopSkill } from "./desktopSkill.js";
import { GeminiClient } from "./geminiClient.js";
import { buildPlannerPrompt, parsePlannedStep } from "./jarvisPlanner.js";
import { VisualParserClient } from "./visualParserClient.js";

export type JarvisEvent =
  | { type: "say"; text: string }
  | { type: "action"; name: string; params: Record<string, unknown> }
  | { type: "error"; text: string };

export type JarvisRunResult = {
  ok: boolean;
  messages: string[];
  events: JarvisEvent[];
};

export class JarvisCore {
  private readonly models: string[];
  private readonly riskyActions: "allow" | "ask";
  private readonly desktopFallback: boolean;
  private readonly visualParserEnabled: boolean;
  private readonly browserUseEnabled: boolean;
  private readonly gemini: GeminiClient;
  private readonly browser = new BrowserSkill();
  private readonly browserUse = new BrowserUseSkill();
  private readonly desktop = new DesktopSkill();
  private readonly visualParser: VisualParserClient;

  constructor(apiKey: string) {
    loadEnv();
    this.models = parseModels(process.env.GEMINI_MODEL, process.env.GEMINI_FALLBACK_MODELS);
    this.riskyActions = process.env.JARVIS_RISKY_ACTIONS === "allow" ? "allow" : "ask";
    this.desktopFallback = process.env.JARVIS_DESKTOP_FALLBACK !== "off";
    this.visualParserEnabled = process.env.JARVIS_VISUAL_PARSER === "on";
    this.browserUseEnabled = process.env.JARVIS_BROWSER_USE !== "off";
    this.gemini = new GeminiClient(apiKey, this.models);
    this.visualParser = new VisualParserClient(process.env.JARVIS_VISUAL_PARSER_URL ?? "http://127.0.0.1:7860/parse");
  }

  async runGoal(goal: string, onEvent?: (event: JarvisEvent) => void): Promise<JarvisRunResult> {
    const events: JarvisEvent[] = [];
    const messages: string[] = [];
    const emit = (event: JarvisEvent) => {
      events.push(event);
      if (event.type === "say" || event.type === "error") messages.push(event.text);
      onEvent?.(event);
    };

    try {
      const history: unknown[] = [];
      let snapshot: unknown = await this.initialSnapshot();

      if (this.browserUseEnabled && process.env.JARVIS_BROWSER_USE_PRIMARY !== "off") {
        snapshot = await this.enrichWithVisualParser(snapshot);
        const browserUseParams = this.enrichBrowserUseParams(
          "browserUse.run",
          {
            task: buildPrimaryBrowserUseTask(goal),
            maxSteps: browserUseMaxStepsForGoal(goal)
          },
          snapshot
        );
        emit({ type: "say", text: "Browser-use main engine se kaam chala raha hoon." });
        emit({ type: "action", name: "browserUse.run", params: browserUseParams });
        try {
          const result = await this.executeAction("browserUse.run", browserUseParams);
          history.push({
            step: 1,
            thought: "Direct browser-use primary run before planner fallback.",
            action: { name: "browserUse.run", params: browserUseParams },
            result
          });
          if (isBrowserUseComplete(result)) {
            const finalResult = browserUseFinalResult(result) || "Task complete kar diya.";
            emit({ type: "say", text: finalResult });
            return { ok: true, messages, events };
          }
          snapshot = await this.observeAfterAction("browserUse.run", result);
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          emit({ type: "error", text: `Browser-use primary failed: ${message}` });
          if (isBrowserUseAiFailure(message)) {
            emit({
              type: "say",
              text: "Browser-use ka AI model quota/rate-limit me atka. Model fallback configured hai; thodi der baad dobara try karo."
            });
            return { ok: false, messages, events };
          }
          snapshot = await this.initialSnapshot().catch(() => ({ mode: "desktop", error: message }));
          history.push({
            step: 1,
            thought: "Browser-use primary run failed; planner may decide a fallback.",
            action: { name: "browserUse.run", params: browserUseParams },
            error: message,
            snapshot
          });
        }
      }

      for (let stepIndex = 0; stepIndex < 16; stepIndex++) {
        snapshot = await this.enrichWithVisualParser(snapshot);
        const prompt = buildPlannerPrompt(goal, sanitizeHistory(history), sanitizeSnapshot(snapshot), {
          riskyActions: this.riskyActions
        });
        const visual = this.visualParserEnabled ? undefined : extractVisual(snapshot);
        const rawPlan = await this.gemini.generateJson<unknown>(prompt, visual ? [visual] : []);
        const plan = parsePlannedStep(rawPlan);

        if (plan.say) emit({ type: "say", text: plan.say });
        if (plan.status !== "continue" || !plan.action) {
          return { ok: true, messages, events };
        }

        const actionParams = this.enrichBrowserUseParams(plan.action.name, plan.action.params, snapshot);
        emit({ type: "action", name: plan.action.name, params: actionParams });
        try {
          const result = await this.executeAction(plan.action.name, actionParams);
          const observed = await this.observeAfterAction(plan.action.name, result);
          history.push({
            step: stepIndex + 1,
            thought: plan.thought,
            action: { ...plan.action, params: actionParams },
            result
          });
          snapshot = observed;
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          emit({ type: "error", text: `Action failed, retrying with page state: ${message}` });
          snapshot = await this.initialSnapshot().catch(() => ({ mode: "desktop", error: message }));
          history.push({
            step: stepIndex + 1,
            thought: plan.thought,
            action: plan.action,
            error: message,
            snapshot
          });
        }
      }

      emit({ type: "say", text: "Step limit aa gayi. Goal ko chhote command me todna padega." });
      return { ok: false, messages, events };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      emit({ type: "error", text: message });
      return { ok: false, messages, events };
    }
  }

  async close(): Promise<void> {
    await this.browser.execute("browser.close", {}).catch(() => undefined);
  }

  private async enrichWithVisualParser(snapshot: unknown): Promise<unknown> {
    if (!this.visualParserEnabled) return snapshot;
    if (!snapshot || typeof snapshot !== "object") return snapshot;
    const value = snapshot as Record<string, unknown>;
    if (typeof value.screenshotBase64 !== "string") return snapshot;
    try {
      return { ...value, visualParser: await this.visualParser.parse(value.screenshotBase64) };
    } catch (error) {
      return { ...value, visualParserError: error instanceof Error ? error.message : String(error) };
    }
  }

  private async initialSnapshot(): Promise<unknown> {
    if (this.visualParserEnabled && this.desktopFallback) {
      return this.desktop.execute("desktop.screenshot", {}).catch(() => this.browser.execute("page.snapshot", {}));
    }

    try {
      return await this.browser.execute("page.snapshot", {});
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (!this.desktopFallback) throw new Error(`Browser mode unavailable: ${message}`);
      return this.desktop.execute("desktop.screenshot", {}).catch(() => ({
        mode: "desktop",
        note: "Browser DOM mode unavailable. Using desktop fallback actions.",
        browserError: message
      }));
    }
  }

  private async observeAfterAction(action: string, result: unknown): Promise<unknown> {
    if (action === "page.snapshot" || action === "desktop.screenshot") return result;

    if (this.visualParserEnabled && this.desktopFallback) {
      return this.desktop.execute("desktop.screenshot", {}).then((snapshot) => ({
        actionResult: result,
        ...asRecord(snapshot)
      })).catch(() => result);
    }

    if (action.startsWith("browserUse.") || action.startsWith("desktop.")) {
      return this.initialSnapshot().catch(() => result);
    }

    return result;
  }

  private async executeAction(action: string, params: Record<string, unknown>): Promise<unknown> {
    if (action.startsWith("browserUse.")) return this.browserUse.execute(action, params);
    if (action.startsWith("desktop.")) return this.desktop.execute(action, params);
    return this.browser.execute(action, params);
  }

  private enrichBrowserUseParams(action: string, params: Record<string, unknown>, snapshot: unknown): Record<string, unknown> {
    if (action !== "browserUse.run") return params;
    const task = typeof params.task === "string" ? params.task : "";
    const visualSummary = summarizeVisualParser(snapshot);
    if (!visualSummary) return params;
    return {
      ...params,
      task: `${task}\n\nCurrent YOLO/visual-parser observation from the active Chrome window:\n${visualSummary}\nUse these visible elements as hints, but interact through browser-use.`
    };
  }
}

function isBrowserUseAiFailure(message: string): boolean {
  return /RESOURCE_EXHAUSTED|429|quota|rate-limit|rate limit|ModelProviderError/i.test(message);
}

function buildPrimaryBrowserUseTask(goal: string): string {
  const lines = [
    `User command: ${goal}`,
    "",
    "Use browser-use as the main driver in the current Chrome session.",
    "Work directly in the active browser/tab when possible.",
    "Use visible UI and real interactions. If the page needs login, OTP, captcha, payment, password, or a final risky submit not clearly requested by the user, stop and say what the user must do.",
    "When the requested task is complete, stop immediately; do not keep browsing."
  ];
  if (isOneShotSubmissionGoal(goal)) {
    lines.push(
      "",
      "One-shot submission guard:",
      "- Send/comment/post/submit the requested text at most once.",
      "- If the exact text is already visible as the latest outgoing message/comment/post, do not send it again; report done.",
      "- Immediately stop after the first successful send/comment/post/submit."
    );
  }
  return lines.join("\n");
}

function browserUseMaxStepsForGoal(goal: string): number {
  return Number(
    isOneShotSubmissionGoal(goal)
      ? process.env.JARVIS_BROWSER_USE_SUBMIT_MAX_STEPS ?? "4"
      : process.env.JARVIS_BROWSER_USE_MAX_STEPS ?? "8"
  );
}

function isOneShotSubmissionGoal(goal: string): boolean {
  return /\b(send|sent|message|comment|post|submit|reply|bhej|bhejo|bhejna|likh\s*kar\s*bhej|comment\s*kar|whatsapp)\b/i.test(goal);
}

function isBrowserUseComplete(result: unknown): boolean {
  if (!result || typeof result !== "object") return false;
  const value = result as Record<string, unknown>;
  return value.engine === "browser-use" && (value.successful === true || value.done === true);
}

function browserUseFinalResult(result: unknown): string {
  if (!result || typeof result !== "object") return "";
  const value = result as Record<string, unknown>;
  return typeof value.finalResult === "string" ? value.finalResult : "";
}

function summarizeVisualParser(snapshot: unknown): string {
  if (!snapshot || typeof snapshot !== "object") return "";
  const source = snapshot as Record<string, unknown>;
  const parser = source.visualParser;
  if (!parser || typeof parser !== "object") return "";
  const elements = (parser as { elements?: unknown }).elements;
  if (!Array.isArray(elements)) return "";

  return elements
    .map((item) => {
      if (!item || typeof item !== "object") return "";
      const element = item as Record<string, unknown>;
      const center = element.center && typeof element.center === "object" ? (element.center as Record<string, unknown>) : {};
      const text = typeof element.text === "string" ? element.text.replace(/\s+/g, " ").trim().slice(0, 100) : "";
      const kind = typeof element.kind === "string" ? element.kind : "element";
      const id = typeof element.id === "string" ? element.id : "";
      if (!text && kind === "region") return "";
      if (!text && !["button", "input", "text"].includes(kind)) return "";
      return `${id} ${kind} "${text}" center=(${center.x ?? "?"},${center.y ?? "?"})`;
    })
    .filter(Boolean)
    .slice(0, 25)
    .join("\n");
}

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
}

function extractVisual(snapshot: unknown): { mimeType: string; base64: string } | undefined {
  if (!snapshot || typeof snapshot !== "object") return undefined;
  const value = snapshot as { screenshotMimeType?: unknown; screenshotBase64?: unknown };
  if (typeof value.screenshotMimeType === "string" && typeof value.screenshotBase64 === "string") {
    return { mimeType: value.screenshotMimeType, base64: value.screenshotBase64 };
  }
  return undefined;
}

function sanitizeHistory(history: unknown[]): unknown[] {
  return history.map((entry) => sanitizeSnapshot(entry));
}

function sanitizeSnapshot(value: unknown): unknown {
  if (Array.isArray(value)) return value.map((item) => sanitizeSnapshot(item));
  if (!value || typeof value !== "object") return value;
  const source = value as Record<string, unknown>;
  const copy: Record<string, unknown> = {};
  for (const [key, item] of Object.entries(source)) {
    copy[key] = key === "screenshotBase64" ? "[attached as image]" : sanitizeSnapshot(item);
  }
  return copy;
}

function parseModels(primary?: string, fallbacks?: string): string[] {
  const models = [primary ?? "gemini-2.5-flash", ...(fallbacks ?? "").split(",")]
    .map((model) => model.trim())
    .filter(Boolean);
  return [...new Set(models)];
}
