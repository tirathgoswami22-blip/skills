import { createInterface } from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { BrowserSkill } from "./browserSkill.js";
import { BrowserUseSkill } from "./browserUseSkill.js";
import { loadEnv, setEnvValue } from "./config.js";
import { DesktopSkill } from "./desktopSkill.js";
import { GeminiClient } from "./geminiClient.js";
import { buildPlannerPrompt, parsePlannedStep } from "./jarvisPlanner.js";
import { VisualParserClient } from "./visualParserClient.js";

loadEnv();

const models = parseModels(process.env.GEMINI_MODEL, process.env.GEMINI_FALLBACK_MODELS);
const riskyActions = process.env.JARVIS_RISKY_ACTIONS === "allow" ? "allow" : "ask";
const desktopFallback = process.env.JARVIS_DESKTOP_FALLBACK !== "off";
const visualParserEnabled = process.env.JARVIS_VISUAL_PARSER === "on";
const browserUseEnabled = process.env.JARVIS_BROWSER_USE !== "off";

const rl = createInterface({ input, output });
const apiKey = await ensureGeminiApiKey();

const gemini = new GeminiClient(apiKey, models);
const browser = new BrowserSkill();
const browserUse = new BrowserUseSkill();
const desktop = new DesktopSkill();
const visualParser = new VisualParserClient(process.env.JARVIS_VISUAL_PARSER_URL ?? "http://127.0.0.1:7860/parse");

output.write("Jarvis browser mode ready. Command likho, exit ke liye 'exit'.\n");

for (;;) {
  const goal = await ask("\nYou > ");
  if (goal === undefined) break;
  const trimmedGoal = goal.trim();
  if (!trimmedGoal) continue;
  if (["exit", "quit"].includes(trimmedGoal.toLowerCase())) break;

  try {
    await runGoal(trimmedGoal);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    output.write(`Jarvis > Error: ${message}\n`);
  }
}

await browser.execute("browser.close", {}).catch(() => undefined);
rl.close();

async function runGoal(goal: string): Promise<void> {
  const history: unknown[] = [];
  let snapshot: unknown = await initialSnapshot();

  if (browserUseEnabled && process.env.JARVIS_BROWSER_USE_PRIMARY !== "off") {
    snapshot = await enrichWithVisualParser(snapshot);
    const browserUseParams = enrichBrowserUseParams(
      "browserUse.run",
      {
        task: buildPrimaryBrowserUseTask(goal),
        maxSteps: browserUseMaxStepsForGoal(goal)
      },
      snapshot
    );
    output.write("Jarvis > Browser-use main engine se kaam chala raha hoon.\n");
    output.write(`Action > browserUse.run ${JSON.stringify(browserUseParams)}\n`);
    try {
      const result = await executeAction("browserUse.run", browserUseParams);
      history.push({
        step: 1,
        thought: "Direct browser-use primary run before planner fallback.",
        action: { name: "browserUse.run", params: browserUseParams },
        result
      });
      if (isBrowserUseComplete(result)) {
        const finalResult = browserUseFinalResult(result);
        if (finalResult) {
          output.write(`Jarvis > ${finalResult}\n`);
        } else {
          output.write("Jarvis > Browser-use ne task complete kar diya.\n");
        }
        return;
      }
      snapshot = await observeAfterAction("browserUse.run", result);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      output.write(`Jarvis > Browser-use primary failed: ${message}\n`);
      if (isBrowserUseAiFailure(message)) {
        output.write("Jarvis > Browser-use ka AI model quota/rate-limit me atka. Model fallback configured hai; thodi der baad ya fallback model se dobara try karo.\n");
        return;
      }
      snapshot = await initialSnapshot().catch(() => ({ mode: "desktop", error: message }));
      history.push({
        step: 1,
        thought: "Browser-use primary run failed; planner may decide a fallback.",
        action: { name: "browserUse.run", params: browserUseParams },
        error: message,
        snapshot
      });
    }
  }

  for (let stepIndex = 0; stepIndex < 16; stepIndex++) {
    snapshot = await enrichWithVisualParser(snapshot);
    const prompt = buildPlannerPrompt(goal, sanitizeHistory(history), sanitizeSnapshot(snapshot), { riskyActions });
    const visual = visualParserEnabled ? undefined : extractVisual(snapshot);
    const rawPlan = await gemini.generateJson<unknown>(prompt, visual ? [visual] : []);
    const plan = parsePlannedStep(rawPlan);

    if (plan.say) {
      output.write(`Jarvis > ${plan.say}\n`);
    }

    if (plan.status !== "continue" || !plan.action) {
      return;
    }

    const actionParams = enrichBrowserUseParams(plan.action.name, plan.action.params, snapshot);
    output.write(`Action > ${plan.action.name} ${JSON.stringify(actionParams)}\n`);
    try {
      const result = await executeAction(plan.action.name, actionParams);
      const observed = await observeAfterAction(plan.action.name, result);
      history.push({
        step: stepIndex + 1,
        thought: plan.thought,
        action: { ...plan.action, params: actionParams },
        result
      });
      snapshot = observed;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      output.write(`Jarvis > Action failed, retrying with page state: ${message}\n`);
      snapshot = await initialSnapshot().catch(() => ({ mode: "desktop", error: message }));
      history.push({
        step: stepIndex + 1,
        thought: plan.thought,
        action: plan.action,
        error: message,
        snapshot
      });
    }
  }

  output.write("Jarvis > Step limit aa gayi. Goal ko chhote command me todna padega.\n");
}

function isBrowserUseAiFailure(message: string): boolean {
  return /RESOURCE_EXHAUSTED|429|quota|rate-limit|rate limit|ModelProviderError/i.test(message);
}

function buildPrimaryBrowserUseTask(goal: string): string {
  const lines = [
    `User command: ${goal}`,
    "",
    "Use browser-use as the main driver in the current Chrome session.",
    "Work directly in the active browser/tab when possible.",
    "Use visible UI and real interactions. If the page needs login, OTP, captcha, payment, password, or a final risky submit not clearly requested by the user, stop and say what the user must do.",
    "When the requested task is complete, stop immediately; do not keep browsing."
  ];

  if (isOneShotSubmissionGoal(goal)) {
    lines.push(
      "",
      "One-shot submission guard:",
      "- Send/comment/post/submit the requested text at most once.",
      "- If the exact text is already visible as the latest outgoing message/comment/post, do not send it again; report done.",
      "- Immediately stop after the first successful send/comment/post/submit."
    );
  }

  return lines.join("\n");
}

function browserUseMaxStepsForGoal(goal: string): number {
  if (isOneShotSubmissionGoal(goal)) {
    return Number(process.env.JARVIS_BROWSER_USE_SUBMIT_MAX_STEPS ?? "4");
  }
  return Number(process.env.JARVIS_BROWSER_USE_MAX_STEPS ?? "8");
}

function isOneShotSubmissionGoal(goal: string): boolean {
  return /\b(send|sent|message|comment|post|submit|reply|bhej|bhejo|bhejna|likh\s*kar\s*bhej|comment\s*kar|whatsapp)\b/i.test(goal);
}

function isBrowserUseComplete(result: unknown): boolean {
  if (!result || typeof result !== "object") return false;
  const value = result as Record<string, unknown>;
  return value.engine === "browser-use" && (value.successful === true || value.done === true);
}

function browserUseFinalResult(result: unknown): string {
  if (!result || typeof result !== "object") return "";
  const value = result as Record<string, unknown>;
  return typeof value.finalResult === "string" ? value.finalResult : "";
}

async function enrichWithVisualParser(snapshot: unknown): Promise<unknown> {
  if (!visualParserEnabled) return snapshot;
  if (!snapshot || typeof snapshot !== "object") return snapshot;
  const value = snapshot as Record<string, unknown>;
  if (typeof value.screenshotBase64 !== "string") return snapshot;
  try {
    return {
      ...value,
      visualParser: await visualParser.parse(value.screenshotBase64)
    };
  } catch (error) {
    return {
      ...value,
      visualParserError: error instanceof Error ? error.message : String(error)
    };
  }
}

async function initialSnapshot(): Promise<unknown> {
  if (visualParserEnabled && desktopFallback) {
    return desktop.execute("desktop.screenshot", {}).catch(() => browser.execute("page.snapshot", {}));
  }

  try {
    return await browser.execute("page.snapshot", {});
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (!desktopFallback) {
      throw new Error(`Browser mode unavailable: ${message}`);
    }
    return desktop.execute("desktop.screenshot", {}).catch(() => ({
      mode: "desktop",
      note: "Browser DOM mode unavailable. Using desktop fallback actions.",
      browserError: message,
      capabilities: [
        "desktop.openChrome",
        "desktop.focusChrome",
        "desktop.addressBar",
        "desktop.type",
        "desktop.key",
        "desktop.click",
        "desktop.screenshot",
        "desktop.closeTab",
        "desktop.wait",
        ...(browserUseEnabled ? ["browserUse.run"] : [])
      ]
    }));
  }
}

async function observeAfterAction(action: string, result: unknown): Promise<unknown> {
  if (action === "page.snapshot" || action === "desktop.screenshot") {
    return result;
  }

  if (visualParserEnabled && desktopFallback) {
    return desktop.execute("desktop.screenshot", {}).then((snapshot) => ({
      actionResult: result,
      ...asRecord(snapshot)
    })).catch(() => result);
  }

  if (action.startsWith("browserUse.") || action.startsWith("desktop.")) {
    return initialSnapshot().catch(() => result);
  }

  return result;
}

async function executeAction(action: string, params: Record<string, unknown>): Promise<unknown> {
  if (action.startsWith("browserUse.")) {
    return browserUse.execute(action, params);
  }
  if (action.startsWith("desktop.")) {
    return desktop.execute(action, params);
  }
  return browser.execute(action, params);
}

function enrichBrowserUseParams(action: string, params: Record<string, unknown>, snapshot: unknown): Record<string, unknown> {
  if (action !== "browserUse.run") return params;
  const task = typeof params.task === "string" ? params.task : "";
  const visualSummary = summarizeVisualParser(snapshot);
  if (!visualSummary) return params;

  return {
    ...params,
    task: `${task}\n\nCurrent YOLO/visual-parser observation from the active Chrome window:\n${visualSummary}\nUse these visible elements as hints, but interact through browser-use.`
  };
}

function summarizeVisualParser(snapshot: unknown): string {
  if (!snapshot || typeof snapshot !== "object") return "";
  const source = snapshot as Record<string, unknown>;
  const parser = source.visualParser;
  if (!parser || typeof parser !== "object") return "";
  const elements = (parser as { elements?: unknown }).elements;
  if (!Array.isArray(elements)) return "";

  return elements
    .map((item) => {
      if (!item || typeof item !== "object") return "";
      const element = item as Record<string, unknown>;
      const center = element.center && typeof element.center === "object" ? (element.center as Record<string, unknown>) : {};
      const text = typeof element.text === "string" ? element.text.replace(/\s+/g, " ").trim().slice(0, 100) : "";
      const kind = typeof element.kind === "string" ? element.kind : "element";
      const id = typeof element.id === "string" ? element.id : "";
      if (!text && kind === "region") return "";
      if (!text && !["button", "input", "text"].includes(kind)) return "";
      return `${id} ${kind} "${text}" center=(${center.x ?? "?"},${center.y ?? "?"})`;
    })
    .filter(Boolean)
    .slice(0, 25)
    .join("\n");
}

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
}

function extractVisual(snapshot: unknown): { mimeType: string; base64: string } | undefined {
  if (!snapshot || typeof snapshot !== "object") return undefined;
  const value = snapshot as { screenshotMimeType?: unknown; screenshotBase64?: unknown };
  if (typeof value.screenshotMimeType === "string" && typeof value.screenshotBase64 === "string") {
    return { mimeType: value.screenshotMimeType, base64: value.screenshotBase64 };
  }
  return undefined;
}

function sanitizeHistory(history: unknown[]): unknown[] {
  return history.map((entry) => sanitizeSnapshot(entry));
}

function sanitizeSnapshot(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map((item) => sanitizeSnapshot(item));
  }
  if (!value || typeof value !== "object") {
    return value;
  }
  const source = value as Record<string, unknown>;
  const copy: Record<string, unknown> = {};
  for (const [key, item] of Object.entries(source)) {
    if (key === "screenshotBase64") {
      copy[key] = "[attached as image]";
    } else {
      copy[key] = sanitizeSnapshot(item);
    }
  }
  return copy;
}

async function ask(question: string): Promise<string | undefined> {
  try {
    return await rl.question(question);
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ERR_USE_AFTER_CLOSE") {
      return undefined;
    }
    throw error;
  }
}

function parseModels(primary?: string, fallbacks?: string): string[] {
  const models = [primary ?? "gemini-2.5-flash", ...(fallbacks ?? "").split(",")]
    .map((model) => model.trim())
    .filter(Boolean);
  return [...new Set(models)];
}

async function ensureGeminiApiKey(): Promise<string> {
  const existing = process.env.GEMINI_API_KEY?.trim();
  if (existing) return existing;

  output.write("Jarvis setup > GEMINI_API_KEY missing hai. Google AI Studio se key paste karo.\n");
  const answer = await ask("Gemini API key > ");
  const apiKey = answer?.trim();
  if (!apiKey) {
    output.write("Jarvis setup > API key nahi mili. Jarvis band kar raha hoon.\n");
    process.exit(1);
  }

  setEnvValue("GEMINI_API_KEY", apiKey);
  output.write("Jarvis setup > API key .env me save ho gayi.\n");
  return apiKey;
}
