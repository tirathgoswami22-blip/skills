$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$skillsRoot = Join-Path $root ".jarvis\skills"
$skillName = "browser-control"
$target = Join-Path $skillsRoot $skillName

Write-Host "Jarvis Browser Skill installer"
Write-Host "Skill name: $skillName"
Write-Host "Install folder: $target"

$answer = Read-Host "Browser Control skill install karni hai? (y/n)"
if ($answer -notin @("y", "Y", "yes", "YES", "ha", "haan")) {
  Write-Host "Skill install skip kar diya."
  exit 0
}

if (Test-Path -LiteralPath $target) {
  Write-Host "Skill already installed hai: $target"
  Write-Host "Update ke liye folder me jaake git pull run kar sakte ho."
  exit 0
}

$repo = Read-Host "Browser skill GitHub repo URL paste karo"
if (-not $repo) {
  throw "GitHub repo URL missing hai."
}

New-Item -ItemType Directory -Force -Path $skillsRoot | Out-Null
git clone $repo $target

Write-Host "Browser Control skill installed: $target"
Write-Host "Ab skill folder me npm install && npm run build chalana hoga, agar repo pe dependencies bundled nahi hain."
