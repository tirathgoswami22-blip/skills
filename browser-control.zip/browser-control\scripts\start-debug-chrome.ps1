$ErrorActionPreference = "Stop"

$envPath = Join-Path (Split-Path -Parent $PSScriptRoot) ".env"
if (Test-Path -LiteralPath $envPath) {
  Get-Content -LiteralPath $envPath | ForEach-Object {
    $line = $_.Trim()
    if (-not $line -or $line.StartsWith("#") -or -not $line.Contains("=")) { return }
    $key, $value = $line.Split("=", 2)
    if (-not [Environment]::GetEnvironmentVariable($key, "Process")) {
      [Environment]::SetEnvironmentVariable($key, $value, "Process")
    }
  }
}

$port = if ($env:JARVIS_CHROME_DEBUG_PORT) { $env:JARVIS_CHROME_DEBUG_PORT } else { "9222" }
$userDataDir = if ($env:JARVIS_CHROME_USER_DATA_DIR) {
  [Environment]::ExpandEnvironmentVariables($env:JARVIS_CHROME_USER_DATA_DIR)
} else {
  Join-Path (Split-Path -Parent $PSScriptRoot) ".jarvis\chrome-profile"
}
if (-not [System.IO.Path]::IsPathRooted($userDataDir)) {
  $userDataDir = Join-Path (Split-Path -Parent $PSScriptRoot) $userDataDir
}
$profile = if ($env:JARVIS_CHROME_PROFILE) { $env:JARVIS_CHROME_PROFILE } else { "Default" }
$chromeExe = if ($env:JARVIS_CHROME_EXE) {
  [Environment]::ExpandEnvironmentVariables($env:JARVIS_CHROME_EXE)
} else {
  $candidates = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
  )
  $candidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
}

if (-not $chromeExe -or -not (Test-Path -LiteralPath $chromeExe)) {
  throw "Chrome exe not found. Set JARVIS_CHROME_EXE in .env."
}

Write-Host "Starting Chrome debug mode on port $port"
Write-Host "Profile: $profile"
Write-Host "User data: $userDataDir"

New-Item -ItemType Directory -Force -Path $userDataDir | Out-Null

Start-Process -FilePath $chromeExe -ArgumentList @(
  "--remote-debugging-port=$port",
  "--user-data-dir=$userDataDir",
  "--profile-directory=$profile",
  "--no-first-run",
  "--no-default-browser-check",
  "about:blank"
)
