import { spawn } from "node:child_process";
import { z } from "zod";
import { SkillError } from "./protocol.js";

const OpenChromeSchema = z.object({
  url: z.string().optional()
});

const TypeSchema = z.object({
  text: z.string(),
  submit: z.boolean().default(false),
  clear: z.boolean().default(false)
});

const KeySchema = z.object({
  keys: z.string().min(1)
});

const ClickSchema = z.object({
  x: z.number().int().min(0),
  y: z.number().int().min(0),
  double: z.boolean().default(false),
  button: z.enum(["left", "right"]).default("left"),
  coordinateMode: z.enum(["window", "screen"]).default("window")
});

const ScrollSchema = z.object({
  direction: z.enum(["up", "down"]).default("down"),
  amount: z.number().int().min(1).max(20).default(5),
  x: z.number().int().min(0).optional(),
  y: z.number().int().min(0).optional(),
  coordinateMode: z.enum(["window", "screen"]).default("window")
});

const WaitSchema = z.object({
  ms: z.number().int().min(100).max(30000).default(1000)
});

export class DesktopSkill {
  async execute(action: string, params: Record<string, unknown>): Promise<unknown> {
    switch (action) {
      case "desktop.openChrome":
        return this.openChrome(params);
      case "desktop.focusChrome":
        return this.focusChrome();
      case "desktop.type":
        return this.type(params);
      case "desktop.key":
        return this.key(params);
      case "desktop.click":
        return this.click(params);
      case "desktop.scroll":
        return this.scroll(params);
      case "desktop.screenshot":
        return this.screenshot();
      case "desktop.wait":
        return this.wait(params);
      case "desktop.closeTab":
        return this.key({ keys: "^w" });
      case "desktop.addressBar":
        return this.key({ keys: "^l" });
      default:
        throw new SkillError("UNKNOWN_DESKTOP_ACTION", `Unknown desktop skill action: ${action}`);
    }
  }

  private async openChrome(params: Record<string, unknown>) {
    const parsed = OpenChromeSchema.parse(params);
    const target = parsed.url ?? "about:blank";
    await runPowerShell(`
$chrome = @(
  "$env:ProgramFiles\\Google\\Chrome\\Application\\chrome.exe",
  "\${env:ProgramFiles(x86)}\\Google\\Chrome\\Application\\chrome.exe",
  "$env:LOCALAPPDATA\\Google\\Chrome\\Application\\chrome.exe"
) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $chrome) { throw "Chrome exe not found" }
Start-Process -FilePath $chrome -ArgumentList @("${psString(target)}")
Start-Sleep -Milliseconds 700
`);
    await this.focusChrome();
    return this.snapshot("Chrome opened/focused.");
  }

  private async focusChrome() {
    await runPowerShell(`
[void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.VisualBasic")
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32Focus {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
}
"@
$chrome = Get-Process chrome -ErrorAction SilentlyContinue |
  Where-Object { $_.MainWindowHandle -ne 0 } |
  Sort-Object StartTime |
  Select-Object -First 1
if (-not $chrome) {
  $chromeExe = @(
    "$env:ProgramFiles\\Google\\Chrome\\Application\\chrome.exe",
    "\${env:ProgramFiles(x86)}\\Google\\Chrome\\Application\\chrome.exe",
    "$env:LOCALAPPDATA\\Google\\Chrome\\Application\\chrome.exe"
  ) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
  if (-not $chromeExe) { throw "Chrome exe not found" }
  Start-Process -FilePath $chromeExe -ArgumentList @("about:blank")
  Start-Sleep -Milliseconds 900
  $chrome = Get-Process chrome -ErrorAction SilentlyContinue |
    Where-Object { $_.MainWindowHandle -ne 0 } |
    Sort-Object StartTime |
    Select-Object -First 1
}
if (-not $chrome) { throw "Could not find or open a visible Chrome window" }
[Win32Focus]::ShowWindowAsync($chrome.MainWindowHandle, 9) | Out-Null
[Win32Focus]::SetForegroundWindow($chrome.MainWindowHandle) | Out-Null
Start-Sleep -Milliseconds 250
`);
    return this.snapshot("Chrome focused.");
  }

  private async type(params: Record<string, unknown>) {
    const parsed = TypeSchema.parse(params);
    await this.focusChrome();
    if (parsed.clear) {
      await sendKeys("^a");
      await sleep(80);
    }
    await setClipboard(parsed.text);
    await sendKeys("^v");
    if (parsed.submit) {
      await sleep(120);
      await sendKeys("{ENTER}");
    }
    return this.snapshot("Typed text into the active Chrome control.");
  }

  private async key(params: Record<string, unknown>) {
    const parsed = KeySchema.parse(params);
    await this.focusChrome();
    await sendKeys(parsed.keys);
    return this.snapshot(`Sent keys: ${parsed.keys}`);
  }

  private async click(params: Record<string, unknown>) {
    const parsed = ClickSchema.parse(params);
    await this.focusChrome();
    const down = parsed.button === "right" ? "0x0008" : "0x0002";
    const up = parsed.button === "right" ? "0x0010" : "0x0004";
    const repeat = parsed.double ? 2 : 1;
    await runPowerShell(`
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32Mouse {
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
}
public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
"@
$chrome = Get-Process chrome -ErrorAction SilentlyContinue |
  Where-Object { $_.MainWindowHandle -ne 0 } |
  Sort-Object StartTime |
  Select-Object -First 1
if (-not $chrome) { throw "Could not find a visible Chrome window" }
$rect = New-Object RECT
[Win32Mouse]::GetWindowRect($chrome.MainWindowHandle, [ref]$rect) | Out-Null
$width = $rect.Right - $rect.Left
$height = $rect.Bottom - $rect.Top
$x = ${parsed.x}
$y = ${parsed.y}
if ("${parsed.coordinateMode}" -eq "window") {
  if ($x -lt 0 -or $y -lt 0 -or $x -gt $width -or $y -gt $height) { throw "Refusing to click outside Chrome window bounds" }
  $x = $rect.Left + $x
  $y = $rect.Top + $y
}
[Win32Mouse]::SetCursorPos($x, $y) | Out-Null
Start-Sleep -Milliseconds 80
for ($i = 0; $i -lt ${repeat}; $i++) {
  [Win32Mouse]::mouse_event(${down}, 0, 0, 0, [UIntPtr]::Zero)
  Start-Sleep -Milliseconds 60
  [Win32Mouse]::mouse_event(${up}, 0, 0, 0, [UIntPtr]::Zero)
  Start-Sleep -Milliseconds 120
}
Start-Sleep -Milliseconds 250
`);
    return this.snapshot(`Clicked at ${parsed.x},${parsed.y} (${parsed.coordinateMode}).`);
  }

  private async scroll(params: Record<string, unknown>) {
    const parsed = ScrollSchema.parse(params);
    await this.focusChrome();
    const wheelDelta = parsed.direction === "up" ? 120 : -120;
    const move = parsed.x !== undefined && parsed.y !== undefined
      ? `
$x = ${parsed.x}
$y = ${parsed.y}
if ("${parsed.coordinateMode}" -eq "window") {
  $chrome = Get-Process chrome -ErrorAction SilentlyContinue |
    Where-Object { $_.MainWindowHandle -ne 0 } |
    Sort-Object StartTime |
    Select-Object -First 1
  if (-not $chrome) { throw "Could not find a visible Chrome window" }
  $rect = New-Object RECT
  [Win32Mouse]::GetWindowRect($chrome.MainWindowHandle, [ref]$rect) | Out-Null
  $width = $rect.Right - $rect.Left
  $height = $rect.Bottom - $rect.Top
  if ($x -lt 0 -or $y -lt 0 -or $x -gt $width -or $y -gt $height) { throw "Refusing to scroll outside Chrome window bounds" }
  $x = $rect.Left + $x
  $y = $rect.Top + $y
}
[Win32Mouse]::SetCursorPos($x, $y) | Out-Null`
      : "";
    await runPowerShell(`
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32Mouse {
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, int dwData, UIntPtr dwExtraInfo);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
}
public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
"@
${move}
Start-Sleep -Milliseconds 80
for ($i = 0; $i -lt ${parsed.amount}; $i++) {
  [Win32Mouse]::mouse_event(0x0800, 0, 0, ${wheelDelta}, [UIntPtr]::Zero)
  Start-Sleep -Milliseconds 60
}
Start-Sleep -Milliseconds 250
`);
    return this.snapshot(`Scrolled ${parsed.direction} ${parsed.amount} wheel steps.`);
  }

  private async screenshot() {
    await this.focusChrome();
    const raw = await runPowerShell(`
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32Rect {
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
}
public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
"@
$chrome = Get-Process chrome -ErrorAction SilentlyContinue |
  Where-Object { $_.MainWindowHandle -ne 0 } |
  Sort-Object StartTime |
  Select-Object -First 1
if (-not $chrome) { throw "Could not find a visible Chrome window" }
$rect = New-Object RECT
[Win32Rect]::GetWindowRect($chrome.MainWindowHandle, [ref]$rect) | Out-Null
$width = [Math]::Max(1, $rect.Right - $rect.Left)
$height = [Math]::Max(1, $rect.Bottom - $rect.Top)
$bitmap = New-Object System.Drawing.Bitmap $width, $height
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
$graphics.CopyFromScreen($rect.Left, $rect.Top, 0, 0, (New-Object System.Drawing.Size($width, $height)))
$stream = New-Object System.IO.MemoryStream
$bitmap.Save($stream, [System.Drawing.Imaging.ImageFormat]::Png)
$graphics.Dispose()
$bitmap.Dispose()
$payload = @{
  base64 = [Convert]::ToBase64String($stream.ToArray())
  bounds = @{
    x = $rect.Left
    y = $rect.Top
    width = $width
    height = $height
  }
} | ConvertTo-Json -Compress
$payload
`);
    const payload = JSON.parse(raw.trim()) as {
      base64: string;
      bounds: { x: number; y: number; width: number; height: number };
    };

    return {
      ...this.snapshot("Captured current screen for visual planning."),
      screenshotMimeType: "image/png",
      screenshotBase64: payload.base64,
      screenshotScope: "chrome-window",
      windowBounds: payload.bounds,
      coordinateMode: "window"
    };
  }

  private async wait(params: Record<string, unknown>) {
    const parsed = WaitSchema.parse(params);
    await sleep(parsed.ms);
    return this.snapshot(`Waited ${parsed.ms}ms.`);
  }

  private snapshot(note: string) {
    return {
      mode: "desktop",
      note,
      capabilities: [
        "desktop.openChrome",
        "desktop.focusChrome",
        "desktop.addressBar",
        "desktop.type",
        "desktop.key",
        "desktop.click",
        "desktop.scroll",
        "desktop.screenshot",
        "desktop.closeTab",
        "desktop.wait"
      ],
      warning:
        "Desktop mode controls Chrome by focus, keyboard, and clipboard. It cannot read DOM elements unless Chrome CDP/browser mode is available."
    };
  }
}

async function sendKeys(keys: string): Promise<void> {
  await runPowerShell(`
$wshell = New-Object -ComObject WScript.Shell
$wshell.SendKeys("${psString(keys)}")
Start-Sleep -Milliseconds 120
`);
}

async function setClipboard(text: string): Promise<void> {
  await runPowerShell(`Set-Clipboard -Value "${psString(text)}"`);
}

function runPowerShell(script: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = spawn("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], {
      windowsHide: true
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => {
      stdout += String(chunk);
    });
    child.stderr.on("data", (chunk) => {
      stderr += String(chunk);
    });
    child.on("error", reject);
    child.on("exit", (code) => {
      if (code === 0) resolve(stdout);
      else reject(new SkillError("DESKTOP_COMMAND_FAILED", stderr.trim() || `PowerShell exited with ${code}`));
    });
  });
}

function psString(input: string): string {
  return input.replace(/`/g, "``").replace(/"/g, '`"').replace(/\$/g, "`$");
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
