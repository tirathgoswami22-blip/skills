import { GeminiClient } from "./geminiClient.js";
import { SkillError } from "./protocol.js";

type Provider = "gemini" | "groq";

type GroqResponse = {
  choices?: Array<{ message?: { content?: string } }>;
  error?: { message?: string };
};

export class LlmClient {
  private readonly provider: Provider;
  private readonly gemini?: GeminiClient;
  private readonly groqModels: string[];

  constructor(apiKey: string) {
    this.provider = parseProvider(process.env.JARVIS_LLM_PROVIDER);
    if (this.provider === "gemini") {
      this.gemini = new GeminiClient(apiKey, parseModels(process.env.GEMINI_MODEL, process.env.GEMINI_FALLBACK_MODELS));
      this.groqModels = [];
    } else {
      this.groqModels = parseModels(process.env.GROQ_MODEL ?? "llama-3.3-70b-versatile", process.env.GROQ_FALLBACK_MODELS);
      if (this.groqModels.length === 0) {
        throw new SkillError("GROQ_MODEL_MISSING", "No Groq model configured.");
      }
    }
  }

  async generateJson<T>(prompt: string, images: Array<{ mimeType: string; base64: string }> = []): Promise<T> {
    if (this.provider === "gemini") {
      return this.gemini!.generateJson<T>(prompt, images);
    }
    if (images.length > 0) {
      throw new SkillError("GROQ_VISION_UNSUPPORTED", "Groq JSON planner is text-only in this Jarvis setup.");
    }
    return this.generateGroqJson<T>(prompt);
  }

  private async generateGroqJson<T>(prompt: string): Promise<T> {
    const apiKey = process.env.GROQ_API_KEY?.trim();
    if (!apiKey) {
      throw new SkillError("GROQ_API_KEY_MISSING", "GROQ_API_KEY missing.");
    }

    let lastError: unknown;
    for (const model of this.groqModels) {
      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          return await this.generateGroqJsonWithModel<T>(apiKey, model, prompt);
        } catch (error) {
          lastError = error;
          if (!isRetryable(error)) break;
          await sleep(400 * attempt);
        }
      }
    }
    throw lastError;
  }

  private async generateGroqJsonWithModel<T>(apiKey: string, model: string, prompt: string): Promise<T> {
    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model,
        messages: [
          {
            role: "system",
            content: "Return only valid JSON. No markdown."
          },
          { role: "user", content: prompt }
        ],
        temperature: 0.1,
        response_format: { type: "json_object" }
      })
    });

    const raw = (await response.json().catch(() => ({}))) as GroqResponse;
    if (!response.ok) {
      throw new SkillError("GROQ_REQUEST_FAILED", raw.error?.message ?? `Groq request failed with ${response.status}`, {
        status: response.status,
        model
      });
    }

    const text = raw.choices?.[0]?.message?.content?.trim();
    if (!text) {
      throw new SkillError("GROQ_EMPTY_RESPONSE", "Groq returned no text.");
    }
    return JSON.parse(stripJsonFence(text)) as T;
  }
}

export function selectedApiKey(): string | undefined {
  return parseProvider(process.env.JARVIS_LLM_PROVIDER) === "groq" ? process.env.GROQ_API_KEY : process.env.GEMINI_API_KEY;
}

function parseProvider(value: string | undefined): Provider {
  return value?.trim().toLowerCase().startsWith("groq") ? "groq" : "gemini";
}

function parseModels(primary?: string, fallbacks?: string): string[] {
  const models = [primary ?? "", ...(fallbacks ?? "").split(",")]
    .map((model) => model.trim())
    .filter(Boolean);
  return [...new Set(models)];
}

function stripJsonFence(text: string): string {
  return text.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/\s*```$/i, "").trim();
}

function isRetryable(error: unknown): boolean {
  if (!(error instanceof SkillError)) return false;
  const details = error.details as { status?: number } | undefined;
  return details?.status === 429 || details?.status === 500 || details?.status === 503;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
