import { GeminiClient } from "./geminiClient.js";

export class LlmClient {
  private readonly gemini: GeminiClient;

  constructor(apiKey: string) {
    this.gemini = new GeminiClient(apiKey, parseModels(process.env.GEMINI_MODEL, process.env.GEMINI_FALLBACK_MODELS));
  }

  async generateJson<T>(prompt: string, images: Array<{ mimeType: string; base64: string }> = []): Promise<T> {
    return this.gemini.generateJson<T>(prompt, images);
  }
}

export function selectedApiKey(): string | undefined {
  return process.env.GEMINI_API_KEY;
}

function parseModels(primary?: string, fallbacks?: string): string[] {
  const models = [primary ?? "gemini-2.5-flash", ...(fallbacks ?? "").split(",")]
    .map((model) => model.trim())
    .filter(Boolean);
  return [...new Set(models)];
}
