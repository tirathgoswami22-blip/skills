import { BrowserSkill } from "./browserSkill.js";
import { BrowserUseSkill } from "./browserUseSkill.js";
import { loadEnv } from "./config.js";
import { DesktopSkill } from "./desktopSkill.js";
import { LlmClient } from "./llmClient.js";
import { buildPlannerPrompt, parsePlannedStep } from "./jarvisPlanner.js";
import { VisualParserClient } from "./visualParserClient.js";
import { WindowsUseSkill } from "./windowsUseSkill.js";

export type JarvisEvent =
  | { type: "say"; text: string }
  | { type: "action"; name: string; params: Record<string, unknown> }
  | { type: "error"; text: string };

export type JarvisRunResult = {
  ok: boolean;
  messages: string[];
  events: JarvisEvent[];
};

type GoalRoute = {
  target: "chat" | "browser" | "windows";
  reply: string;
};

export class JarvisCore {
  private readonly models: string[];
  private readonly riskyActions: "allow" | "ask";
  private readonly desktopFallback: boolean;
  private readonly visualParserEnabled: boolean;
  private readonly browserUseEnabled: boolean;
  private readonly windowsUseEnabled: boolean;
  private readonly language: "hi" | "en";
  private readonly llm: LlmClient;
  private readonly browser = new BrowserSkill();
  private readonly browserUse = new BrowserUseSkill();
  private readonly desktop = new DesktopSkill();
  private readonly windowsUse = new WindowsUseSkill();
  private readonly visualParser: VisualParserClient;

  constructor(apiKey: string) {
    loadEnv();
    this.models = parseModels(process.env.GEMINI_MODEL, process.env.GEMINI_FALLBACK_MODELS);
    this.riskyActions = process.env.JARVIS_RISKY_ACTIONS === "allow" ? "allow" : "ask";
    this.desktopFallback = process.env.JARVIS_DESKTOP_FALLBACK !== "off";
    this.visualParserEnabled = process.env.JARVIS_VISUAL_PARSER === "on";
    this.browserUseEnabled = process.env.JARVIS_BROWSER_USE !== "off";
    this.windowsUseEnabled = process.env.JARVIS_WINDOWS_USE !== "off" && this.windowsUse.isInstalled();
    this.language = parseLanguage(process.env.JARVIS_LANGUAGE);
    this.llm = new LlmClient(apiKey);
    this.visualParser = new VisualParserClient(process.env.JARVIS_VISUAL_PARSER_URL ?? "http://127.0.0.1:7860/parse");
  }

  async runGoal(goal: string, onEvent?: (event: JarvisEvent) => void): Promise<JarvisRunResult> {
    const events: JarvisEvent[] = [];
    const messages: string[] = [];
    const emit = (event: JarvisEvent) => {
      events.push(event);
      if (event.type === "say" || event.type === "error") messages.push(event.text);
      onEvent?.(event);
    };

    try {
      const route = await this.routeGoal(goal);
      if (route.target === "chat") {
        emit({ type: "say", text: route.reply });
        return { ok: true, messages, events };
      }

      if (route.target === "windows" && !this.windowsUseEnabled) {
        emit({ type: "say", text: this.language === "hi"
          ? "Boss, ye Windows/app wala kaam hai. Iske liye optional windows-control skill install karni padegi. Setup dobara chala kar windows-control select kar dijiye."
          : "Boss, this is a Windows/app task. Please rerun setup and select the optional windows-control skill." });
        return { ok: false, messages, events };
      }

      const history: unknown[] = [];
      let snapshot: unknown;

      if (route.target === "windows") {
        const windowsUseParams = {
          task: buildWindowsUseTask(goal, this.language),
          maxSteps: windowsUseMaxStepsForGoal(goal)
        };
        emit({ type: "say", text: route.reply || phrase(this.language, "start") });
        emit({ type: "action", name: "windowsUse.run", params: windowsUseParams });
        try {
          const result = await this.executeAction("windowsUse.run", windowsUseParams);
          if (isAgentComplete(result)) {
            emit({ type: "say", text: agentFinalResult(result, this.language) || phrase(this.language, "done") });
            return { ok: true, messages, events };
          }
          history.push({
            step: 1,
            thought: "Windows-use primary run before planner fallback.",
            action: { name: "windowsUse.run", params: windowsUseParams },
            result
          });
          emit({ type: "say", text: this.language === "hi"
            ? "Boss, Windows-control ne kaam complete confirm nahi kiya. Main browser me ye kaam try nahi karungi kyunki ye Windows wala task hai."
            : "Boss, Windows-control did not confirm completion. I will not try this in the browser because this is a Windows task." });
          return { ok: false, messages, events };
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          emit({ type: "error", text: `Windows-control failed: ${message}` });
          emit({ type: "say", text: this.language === "hi"
            ? "Boss, Windows-control me error aaya. Ye Windows wala kaam hai, isliye main Chrome/browser fallback nahi chalaungi."
            : "Boss, Windows-control failed. This is a Windows task, so I will not run browser fallback." });
          return { ok: false, messages, events };
        }
      }

      snapshot = await this.initialSnapshot();

      if (this.browserUseEnabled && process.env.JARVIS_BROWSER_USE_PRIMARY !== "off") {
        snapshot = await this.enrichWithVisualParser(snapshot);
        const browserUseParams = this.enrichBrowserUseParams(
          "browserUse.run",
          {
            task: buildPrimaryBrowserUseTask(goal, this.language),
            maxSteps: browserUseMaxStepsForGoal(goal)
          },
          snapshot
        );
        emit({ type: "say", text: route.reply || phrase(this.language, "start") });
        emit({ type: "action", name: "browserUse.run", params: browserUseParams });
        try {
          const result = await this.executeAction("browserUse.run", browserUseParams);
          history.push({
            step: 1,
            thought: "Direct browser-use primary run before planner fallback.",
            action: { name: "browserUse.run", params: browserUseParams },
            result
          });
          if (isBrowserUseComplete(result)) {
            const finalResult = browserUseFinalResult(result, this.language) || phrase(this.language, "done");
            emit({ type: "say", text: finalResult });
            return { ok: true, messages, events };
          }
          snapshot = await this.observeAfterAction("browserUse.run", result);
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          emit({ type: "error", text: `Browser-use primary failed: ${message}` });
          if (isBrowserUseAiFailure(message)) {
            emit({
              type: "say",
              text: phrase(this.language, "quota")
            });
            return { ok: false, messages, events };
          }
          snapshot = await this.initialSnapshot().catch(() => ({ mode: "desktop", error: message }));
          history.push({
            step: 1,
            thought: "Browser-use primary run failed; planner may decide a fallback.",
            action: { name: "browserUse.run", params: browserUseParams },
            error: message,
            snapshot
          });
        }
      }

      for (let stepIndex = 0; stepIndex < 16; stepIndex++) {
        snapshot = await this.enrichWithVisualParser(snapshot);
        const prompt = buildPlannerPrompt(goal, sanitizeHistory(history), sanitizeSnapshot(snapshot), {
          riskyActions: this.riskyActions
        });
        const visual = this.visualParserEnabled ? undefined : extractVisual(snapshot);
        const rawPlan = await this.llm.generateJson<unknown>(prompt, visual ? [visual] : []);
        const plan = parsePlannedStep(rawPlan);

        if (plan.say) emit({ type: "say", text: plan.say });
        if (plan.status !== "continue" || !plan.action) {
          return { ok: true, messages, events };
        }

        const actionParams = this.enrichBrowserUseParams(plan.action.name, plan.action.params, snapshot);
        emit({ type: "action", name: plan.action.name, params: actionParams });
        try {
          const result = await this.executeAction(plan.action.name, actionParams);
          const observed = await this.observeAfterAction(plan.action.name, result);
          history.push({
            step: stepIndex + 1,
            thought: plan.thought,
            action: { ...plan.action, params: actionParams },
            result
          });
          snapshot = observed;
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          emit({ type: "error", text: `Action failed, retrying with page state: ${message}` });
          snapshot = await this.initialSnapshot().catch(() => ({ mode: "desktop", error: message }));
          history.push({
            step: stepIndex + 1,
            thought: plan.thought,
            action: plan.action,
            error: message,
            snapshot
          });
        }
      }

      emit({ type: "say", text: phrase(this.language, "stepLimit") });
      return { ok: false, messages, events };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      emit({ type: "error", text: message });
      return { ok: false, messages, events };
    }
  }

  async close(): Promise<void> {
    await this.browser.execute("browser.close", {}).catch(() => undefined);
  }

  private async enrichWithVisualParser(snapshot: unknown): Promise<unknown> {
    if (!this.visualParserEnabled) return snapshot;
    if (!snapshot || typeof snapshot !== "object") return snapshot;
    const value = snapshot as Record<string, unknown>;
    if (typeof value.screenshotBase64 !== "string") return snapshot;
    try {
      return { ...value, visualParser: await this.visualParser.parse(value.screenshotBase64) };
    } catch (error) {
      return { ...value, visualParserError: error instanceof Error ? error.message : String(error) };
    }
  }

  private async initialSnapshot(): Promise<unknown> {
    if (this.visualParserEnabled && this.desktopFallback) {
      return this.desktop.execute("desktop.screenshot", {}).catch(() => this.browser.execute("page.snapshot", {}));
    }

    try {
      return await this.browser.execute("page.snapshot", {});
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (!this.desktopFallback) throw new Error(`Browser mode unavailable: ${message}`);
      return this.desktop.execute("desktop.screenshot", {}).catch(() => ({
        mode: "desktop",
        note: "Browser DOM mode unavailable. Using desktop fallback actions.",
        browserError: message
      }));
    }
  }

  private async observeAfterAction(action: string, result: unknown): Promise<unknown> {
    if (action === "page.snapshot" || action === "desktop.screenshot") return result;

    if (this.visualParserEnabled && this.desktopFallback) {
      return this.desktop.execute("desktop.screenshot", {}).then((snapshot) => ({
        actionResult: result,
        ...asRecord(snapshot)
      })).catch(() => result);
    }

    if (action.startsWith("browserUse.") || action.startsWith("desktop.")) {
      return this.initialSnapshot().catch(() => result);
    }

    return result;
  }

  private async executeAction(action: string, params: Record<string, unknown>): Promise<unknown> {
    if (action.startsWith("windowsUse.")) return this.windowsUse.execute(action, params);
    if (action.startsWith("browserUse.")) return this.browserUse.execute(action, params);
    if (action.startsWith("desktop.")) return this.desktop.execute(action, params);
    return this.browser.execute(action, params);
  }

  private enrichBrowserUseParams(action: string, params: Record<string, unknown>, snapshot: unknown): Record<string, unknown> {
    if (action !== "browserUse.run") return params;
    const task = typeof params.task === "string" ? params.task : "";
    const visualSummary = summarizeVisualParser(snapshot);
    if (!visualSummary) return params;
    return {
      ...params,
      task: `${task}\n\nCurrent YOLO/visual-parser observation from the active Chrome window:\n${visualSummary}\nUse these visible elements as hints, but interact through browser-use.`
    };
  }

  private async routeGoal(goal: string): Promise<GoalRoute> {
    const prompt = `You are Jarvis, a warm voice assistant.

Decide which engine must handle the user's message: chat, browser, or windows.

Language mode: ${this.language === "hi" ? "Hindi/Hinglish only" : "English only"}.

Engine choice rules:
- target "chat": greetings, casual talk, normal questions, "kaise ho", "kya kar rahi ho", jokes, explanations that do not require controlling the computer.
- target "browser": Chrome/browser/website/web/URL/search engine/YouTube/WhatsApp Web/Gmail/web app/tab/video/download-from-website tasks.
- target "windows": Windows OS and local computer tasks: Terminal, PowerShell, CMD, Notepad, Calculator, File Explorer, folders, files, copy/move/zip/extract/rename/delete, settings, brightness, volume, Wi-Fi, Bluetooth, taskbar, start menu, installed desktop apps, app window maximize/minimize/resize/close, local downloads folder, local Desktop/Documents work.
- If the user says "terminal kholo", "टर्मिनल खोल", "powershell open", "cmd chalao", "notepad kholo", or asks for any installed app, target MUST be "windows".
- If the task can be done without a website/browser, prefer "windows".
- Never choose browser for terminal, PowerShell, CMD, Notepad, Calculator, File Explorer, settings, brightness, or local files.

Rules:
- If the user is greeting, asking how you are, asking what you are doing, joking, chatting, or asking a normal conversational question, return kind "chat".
- If the user asks to open/search/play/click/type/send/post/comment/download/upload/control a website/app/browser/computer, choose browser or windows by the engine choice rules.
- For kind "chat", write a natural response yourself. Do not mention Chrome or browser.
- For browser/windows, write a short energetic acknowledgement before work begins.
- In Hindi mode, speak naturally in Hinglish/Hindi, address the user as "boss", and do not use English sentences.
- In English mode, reply in English.

Return only JSON:
{"target":"chat"|"browser"|"windows","reply":"short user-facing reply"}

User message:
${goal}`;

    try {
      const routed = await this.llm.generateJson<unknown>(prompt);
      if (!routed || typeof routed !== "object") throw new Error("bad route");
      const value = routed as Record<string, unknown>;
      const rawTarget = typeof value.target === "string" ? value.target.trim().toLowerCase() : "";
      const target = normalizeTarget(goal, rawTarget === "windows" ? "windows" : rawTarget === "browser" ? "browser" : rawTarget === "chat" ? "chat" : heuristicTarget(goal));
      const reply = typeof value.reply === "string" ? value.reply.trim() : "";
      return { target, reply: reply || (target === "chat" ? phrase(this.language, "chat") : phrase(this.language, "start")) };
    } catch {
      const target = heuristicTarget(goal);
      return { target, reply: target === "chat" ? phrase(this.language, "chat") : phrase(this.language, "start") };
    }
  }
}

function isBrowserUseAiFailure(message: string): boolean {
  return /RESOURCE_EXHAUSTED|429|quota|rate-limit|rate limit|ModelProviderError/i.test(message);
}

function buildPrimaryBrowserUseTask(goal: string, language: "hi" | "en"): string {
  const lines = [
    `User command: ${goal}`,
    "",
    "Use browser-use as the main driver in the current Chrome session.",
    "Work directly in the active browser/tab when possible.",
    "Use visible UI and real interactions. If the page needs login, OTP, captcha, payment, password, or a final risky submit not clearly requested by the user, stop and say what the user must do.",
    "When the requested task is complete, stop immediately; do not keep browsing.",
    language === "hi"
      ? "All user-facing status and final response must be in natural, energetic Hindi/Hinglish, addressing the user as boss. Do not answer in English."
      : "All user-facing status and final response must be in clear English."
  ];
  if (isOneShotSubmissionGoal(goal)) {
    lines.push(
      "",
      "One-shot submission guard:",
      "- Send/comment/post/submit the requested text at most once.",
      "- If the exact text is already visible as the latest outgoing message/comment/post, do not send it again; report done.",
      "- Immediately stop after the first successful send/comment/post/submit."
    );
  }
  return lines.join("\n");
}

function browserUseMaxStepsForGoal(goal: string): number {
  return Number(
    isOneShotSubmissionGoal(goal)
      ? process.env.JARVIS_BROWSER_USE_SUBMIT_MAX_STEPS ?? "4"
      : process.env.JARVIS_BROWSER_USE_MAX_STEPS ?? "8"
  );
}

function isOneShotSubmissionGoal(goal: string): boolean {
  return /\b(send|sent|message|comment|post|submit|reply|bhej|bhejo|bhejna|likh\s*kar\s*bhej|comment\s*kar|whatsapp)\b/i.test(goal);
}

function isBrowserUseComplete(result: unknown): boolean {
  return isAgentComplete(result);
}

function isAgentComplete(result: unknown): boolean {
  if (!result || typeof result !== "object") return false;
  const value = result as Record<string, unknown>;
  return (value.engine === "browser-use" || value.engine === "computer-use") && (value.successful === true || value.done === true);
}

function browserUseFinalResult(result: unknown, language: "hi" | "en"): string {
  return agentFinalResult(result, language);
}

function agentFinalResult(result: unknown, language: "hi" | "en"): string {
  if (!result || typeof result !== "object") return "";
  const value = result as Record<string, unknown>;
  const raw = typeof value.finalResult === "string" ? value.finalResult : "";
  if (!raw) return "";
  if (language === "hi") {
    if (/login|captcha|otp|password|sign in/i.test(raw)) return "Boss, yahan login ya verification chahiye. Aap ek baar manually kar dijiye, phir main aage sambhal lungi.";
    return "Ho gaya boss, kaam complete kar diya.";
  }
  return raw;
}

function buildWindowsUseTask(goal: string, language: "hi" | "en"): string {
  return [
    `User command: ${goal}`,
    "",
    "Use Jarvis Computer Use as the main driver for this Windows desktop task.",
    "Computer Use works by taking screenshots, parsing visible screen elements, asking Gemini for the next action, then controlling the PC with PyAutoGUI/PowerShell.",
    "Do not open Chrome or any browser unless the user explicitly asked for a browser/website/URL/web app.",
    "Use Windows accessibility tree, screenshot/vision, and real UI interactions. You may open apps, switch windows, resize, type, click, scroll, run PowerShell, and manage files/settings when the user clearly asked for it.",
    "For Terminal/PowerShell/CMD requests, open Windows Terminal, PowerShell, or Command Prompt directly through Windows UI or shell, not Chrome.",
    "Before destructive actions like delete/overwrite/permanent changes, stop and ask unless the user explicitly requested that exact destructive action.",
    "Stop immediately when the task is complete.",
    language === "hi"
      ? "All user-facing status and final response must be in natural energetic Hindi/Hinglish, addressing the user as boss. Do not answer in English."
      : "All user-facing status and final response must be in clear English."
  ].join("\n");
}

function windowsUseMaxStepsForGoal(goal: string): number {
  const longTask = /\b(copy|move|zip|extract|install|setting|settings|brightness|folder|file|notepad|excel|word|powerpoint|explorer|desktop|app|window|rename|delete|edit|save)\b/i.test(goal);
  return Number(process.env.JARVIS_WINDOWS_USE_MAX_STEPS ?? (longTask ? "35" : "20"));
}

function isWindowsDesktopTask(goal: string): boolean {
  const text = goal.toLowerCase();
  if (isBrowserTask(text)) return false;
  return isWindowsTask(text);
}

function heuristicTarget(goal: string): GoalRoute["target"] {
  const text = goal.toLowerCase();
  if (isWindowsTask(text) && !isBrowserTask(text)) return "windows";
  if (isBrowserTask(text) || isLikelyTask(text)) return "browser";
  return "chat";
}

function normalizeTarget(goal: string, target: GoalRoute["target"]): GoalRoute["target"] {
  const text = goal.toLowerCase();
  if (isWindowsTask(text) && !isBrowserTask(text)) return "windows";
  if (isBrowserTask(text)) return "browser";
  return target;
}

function isBrowserTask(text: string): boolean {
  return /\b(chrome|browser|website|web|youtube|google|whatsapp|gmail|tab|url|link|video|site)\b/i.test(text)
    || /(chrome|browser|youtube|google|website|web|url|link|site|whatsapp|gmail|video)\s+(khol|kholo|open|chala|chalao|laga|lagao|search|dhund|चल|चलाओ|खोल|खोलो)/i.test(text)
    || /(वेबसाइट|ब्राउजर|ब्राउज़र|यूट्यूब|गूगल|क्रोम|वीडियो)/i.test(text);
}

function isWindowsTask(text: string): boolean {
  return /\b(windows|desktop|notepad|calculator|paint|explorer|folder|file|copy|move|zip|extract|rename|delete|brightness|setting|settings|app|window|minimize|maximize|resize|powershell|cmd|terminal|command prompt|taskbar|start menu|control panel|volume|wifi|bluetooth|downloads|documents)\b/i.test(text)
    || /(terminal|powershell|cmd|command prompt|notepad|calculator|paint|explorer|folder|file|setting|settings|brightness|volume|wifi|bluetooth|taskbar|start menu|downloads|documents|desktop).*(khol|kholo|open|chala|chalao|band|close|bada|chhota|minimize|maximize|copy|move|zip|extract|rename|delete|edit|save|खोल|खोलो|चल|चलाओ|बंद)/i.test(text)
    || /(khol|kholo|open|chala|chalao|band|close|खोल|खोलो|चल|चलाओ|बंद).*(terminal|powershell|cmd|command prompt|notepad|calculator|paint|explorer|folder|file|setting|settings|app|downloads|documents)/i.test(text)
    || /(टर्मिनल|पावरशेल|कमांड|नोटपैड|कैलकुलेटर|फाइल|फोल्डर|सेटिंग|ब्राइटनेस|वॉल्यूम|वाई.?फाई|ब्लूटूथ|डेस्कटॉप|डाउनलोड|डॉक्यूमेंट)/i.test(text);
}

function summarizeVisualParser(snapshot: unknown): string {
  if (!snapshot || typeof snapshot !== "object") return "";
  const source = snapshot as Record<string, unknown>;
  const parser = source.visualParser;
  if (!parser || typeof parser !== "object") return "";
  const elements = (parser as { elements?: unknown }).elements;
  if (!Array.isArray(elements)) return "";

  return elements
    .map((item) => {
      if (!item || typeof item !== "object") return "";
      const element = item as Record<string, unknown>;
      const center = element.center && typeof element.center === "object" ? (element.center as Record<string, unknown>) : {};
      const text = typeof element.text === "string" ? element.text.replace(/\s+/g, " ").trim().slice(0, 100) : "";
      const kind = typeof element.kind === "string" ? element.kind : "element";
      const id = typeof element.id === "string" ? element.id : "";
      if (!text && kind === "region") return "";
      if (!text && !["button", "input", "text"].includes(kind)) return "";
      return `${id} ${kind} "${text}" center=(${center.x ?? "?"},${center.y ?? "?"})`;
    })
    .filter(Boolean)
    .slice(0, 25)
    .join("\n");
}

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
}

function extractVisual(snapshot: unknown): { mimeType: string; base64: string } | undefined {
  if (!snapshot || typeof snapshot !== "object") return undefined;
  const value = snapshot as { screenshotMimeType?: unknown; screenshotBase64?: unknown };
  if (typeof value.screenshotMimeType === "string" && typeof value.screenshotBase64 === "string") {
    return { mimeType: value.screenshotMimeType, base64: value.screenshotBase64 };
  }
  return undefined;
}

function sanitizeHistory(history: unknown[]): unknown[] {
  return history.map((entry) => sanitizeSnapshot(entry));
}

function sanitizeSnapshot(value: unknown): unknown {
  if (Array.isArray(value)) return value.map((item) => sanitizeSnapshot(item));
  if (!value || typeof value !== "object") return value;
  const source = value as Record<string, unknown>;
  const copy: Record<string, unknown> = {};
  for (const [key, item] of Object.entries(source)) {
    copy[key] = key === "screenshotBase64" ? "[attached as image]" : sanitizeSnapshot(item);
  }
  return copy;
}

function parseModels(primary?: string, fallbacks?: string): string[] {
  const models = [primary ?? "gemini-2.5-flash", ...(fallbacks ?? "").split(",")]
    .map((model) => model.trim())
    .filter(Boolean);
  return [...new Set(models)];
}

function parseLanguage(value: string | undefined): "hi" | "en" {
  return value?.trim().toLowerCase().startsWith("en") ? "en" : "hi";
}

function phrase(language: "hi" | "en", key: "start" | "done" | "quota" | "stepLimit" | "chat"): string {
  if (language === "en") {
    return {
      start: "Sure boss, I am working on it now.",
      done: "Done boss, I completed the task.",
      quota: "Boss, the AI model is rate-limited right now. Please try again in a little while.",
      stepLimit: "Boss, this task got too long. Please break it into a smaller command.",
      chat: "Yes boss, I am listening."
    }[key];
  }
  return {
    start: "Theek hai boss, main abhi ye kaam karti hoon. Aap bas ek pal rukiye.",
    done: "Ho gaya boss, kaam complete kar diya.",
    quota: "Boss, AI model abhi rate-limit me atak gaya hai. Thodi der baad dobara try karte hain.",
    stepLimit: "Boss, ye kaam thoda lamba ho gaya. Isko chhote command me bol dijiye, main turant kar dungi.",
    chat: "Haan boss, main sun rahi hoon. Aap araam se boliye."
  }[key];
}

function isLikelyTask(goal: string): boolean {
  return /\b(open|search|play|click|type|send|message|comment|post|close|download|upload|find|navigate|google|youtube|whatsapp|chrome|tab|video|website|khol|kholo|chala|chalao|laga|lagao|bhej|bhejo|comment|dhund|band|likh|dabao)\b/i.test(goal)
    || /(खोल|खोलो|चल|चलाओ|लगा|लगाओ|भेज|ढूंढ|बंद|लिख|दबाओ)/i.test(goal);
}
