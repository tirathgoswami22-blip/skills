import { BrowserSkill } from "./browserSkill.js";
import { BrowserUseSkill } from "./browserUseSkill.js";
import { loadEnv } from "./config.js";
import { DesktopSkill } from "./desktopSkill.js";
import { GeminiClient } from "./geminiClient.js";
import { buildPlannerPrompt, parsePlannedStep } from "./jarvisPlanner.js";
import { VisualParserClient } from "./visualParserClient.js";

export type JarvisEvent =
  | { type: "say"; text: string }
  | { type: "action"; name: string; params: Record<string, unknown> }
  | { type: "error"; text: string };

export type JarvisRunResult = {
  ok: boolean;
  messages: string[];
  events: JarvisEvent[];
};

export class JarvisCore {
  private readonly models: string[];
  private readonly riskyActions: "allow" | "ask";
  private readonly desktopFallback: boolean;
  private readonly visualParserEnabled: boolean;
  private readonly browserUseEnabled: boolean;
  private readonly language: "hi" | "en";
  private readonly gemini: GeminiClient;
  private readonly browser = new BrowserSkill();
  private readonly browserUse = new BrowserUseSkill();
  private readonly desktop = new DesktopSkill();
  private readonly visualParser: VisualParserClient;

  constructor(apiKey: string) {
    loadEnv();
    this.models = parseModels(process.env.GEMINI_MODEL, process.env.GEMINI_FALLBACK_MODELS);
    this.riskyActions = process.env.JARVIS_RISKY_ACTIONS === "allow" ? "allow" : "ask";
    this.desktopFallback = process.env.JARVIS_DESKTOP_FALLBACK !== "off";
    this.visualParserEnabled = process.env.JARVIS_VISUAL_PARSER === "on";
    this.browserUseEnabled = process.env.JARVIS_BROWSER_USE !== "off";
    this.language = parseLanguage(process.env.JARVIS_LANGUAGE);
    this.gemini = new GeminiClient(apiKey, this.models);
    this.visualParser = new VisualParserClient(process.env.JARVIS_VISUAL_PARSER_URL ?? "http://127.0.0.1:7860/parse");
  }

  async runGoal(goal: string, onEvent?: (event: JarvisEvent) => void): Promise<JarvisRunResult> {
    const events: JarvisEvent[] = [];
    const messages: string[] = [];
    const emit = (event: JarvisEvent) => {
      events.push(event);
      if (event.type === "say" || event.type === "error") messages.push(event.text);
      onEvent?.(event);
    };

    try {
      const conversationalReply = quickConversationReply(goal, this.language);
      if (conversationalReply) {
        emit({ type: "say", text: conversationalReply });
        return { ok: true, messages, events };
      }

      const history: unknown[] = [];
      let snapshot: unknown = await this.initialSnapshot();

      if (this.browserUseEnabled && process.env.JARVIS_BROWSER_USE_PRIMARY !== "off") {
        snapshot = await this.enrichWithVisualParser(snapshot);
        const browserUseParams = this.enrichBrowserUseParams(
          "browserUse.run",
          {
            task: buildPrimaryBrowserUseTask(goal, this.language),
            maxSteps: browserUseMaxStepsForGoal(goal)
          },
          snapshot
        );
        emit({ type: "say", text: phrase(this.language, "start") });
        emit({ type: "action", name: "browserUse.run", params: browserUseParams });
        try {
          const result = await this.executeAction("browserUse.run", browserUseParams);
          history.push({
            step: 1,
            thought: "Direct browser-use primary run before planner fallback.",
            action: { name: "browserUse.run", params: browserUseParams },
            result
          });
          if (isBrowserUseComplete(result)) {
            const finalResult = browserUseFinalResult(result, this.language) || phrase(this.language, "done");
            emit({ type: "say", text: finalResult });
            return { ok: true, messages, events };
          }
          snapshot = await this.observeAfterAction("browserUse.run", result);
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          emit({ type: "error", text: `Browser-use primary failed: ${message}` });
          if (isBrowserUseAiFailure(message)) {
            emit({
              type: "say",
              text: phrase(this.language, "quota")
            });
            return { ok: false, messages, events };
          }
          snapshot = await this.initialSnapshot().catch(() => ({ mode: "desktop", error: message }));
          history.push({
            step: 1,
            thought: "Browser-use primary run failed; planner may decide a fallback.",
            action: { name: "browserUse.run", params: browserUseParams },
            error: message,
            snapshot
          });
        }
      }

      for (let stepIndex = 0; stepIndex < 16; stepIndex++) {
        snapshot = await this.enrichWithVisualParser(snapshot);
        const prompt = buildPlannerPrompt(goal, sanitizeHistory(history), sanitizeSnapshot(snapshot), {
          riskyActions: this.riskyActions
        });
        const visual = this.visualParserEnabled ? undefined : extractVisual(snapshot);
        const rawPlan = await this.gemini.generateJson<unknown>(prompt, visual ? [visual] : []);
        const plan = parsePlannedStep(rawPlan);

        if (plan.say) emit({ type: "say", text: plan.say });
        if (plan.status !== "continue" || !plan.action) {
          return { ok: true, messages, events };
        }

        const actionParams = this.enrichBrowserUseParams(plan.action.name, plan.action.params, snapshot);
        emit({ type: "action", name: plan.action.name, params: actionParams });
        try {
          const result = await this.executeAction(plan.action.name, actionParams);
          const observed = await this.observeAfterAction(plan.action.name, result);
          history.push({
            step: stepIndex + 1,
            thought: plan.thought,
            action: { ...plan.action, params: actionParams },
            result
          });
          snapshot = observed;
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          emit({ type: "error", text: `Action failed, retrying with page state: ${message}` });
          snapshot = await this.initialSnapshot().catch(() => ({ mode: "desktop", error: message }));
          history.push({
            step: stepIndex + 1,
            thought: plan.thought,
            action: plan.action,
            error: message,
            snapshot
          });
        }
      }

      emit({ type: "say", text: phrase(this.language, "stepLimit") });
      return { ok: false, messages, events };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      emit({ type: "error", text: message });
      return { ok: false, messages, events };
    }
  }

  async close(): Promise<void> {
    await this.browser.execute("browser.close", {}).catch(() => undefined);
  }

  private async enrichWithVisualParser(snapshot: unknown): Promise<unknown> {
    if (!this.visualParserEnabled) return snapshot;
    if (!snapshot || typeof snapshot !== "object") return snapshot;
    const value = snapshot as Record<string, unknown>;
    if (typeof value.screenshotBase64 !== "string") return snapshot;
    try {
      return { ...value, visualParser: await this.visualParser.parse(value.screenshotBase64) };
    } catch (error) {
      return { ...value, visualParserError: error instanceof Error ? error.message : String(error) };
    }
  }

  private async initialSnapshot(): Promise<unknown> {
    if (this.visualParserEnabled && this.desktopFallback) {
      return this.desktop.execute("desktop.screenshot", {}).catch(() => this.browser.execute("page.snapshot", {}));
    }

    try {
      return await this.browser.execute("page.snapshot", {});
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (!this.desktopFallback) throw new Error(`Browser mode unavailable: ${message}`);
      return this.desktop.execute("desktop.screenshot", {}).catch(() => ({
        mode: "desktop",
        note: "Browser DOM mode unavailable. Using desktop fallback actions.",
        browserError: message
      }));
    }
  }

  private async observeAfterAction(action: string, result: unknown): Promise<unknown> {
    if (action === "page.snapshot" || action === "desktop.screenshot") return result;

    if (this.visualParserEnabled && this.desktopFallback) {
      return this.desktop.execute("desktop.screenshot", {}).then((snapshot) => ({
        actionResult: result,
        ...asRecord(snapshot)
      })).catch(() => result);
    }

    if (action.startsWith("browserUse.") || action.startsWith("desktop.")) {
      return this.initialSnapshot().catch(() => result);
    }

    return result;
  }

  private async executeAction(action: string, params: Record<string, unknown>): Promise<unknown> {
    if (action.startsWith("browserUse.")) return this.browserUse.execute(action, params);
    if (action.startsWith("desktop.")) return this.desktop.execute(action, params);
    return this.browser.execute(action, params);
  }

  private enrichBrowserUseParams(action: string, params: Record<string, unknown>, snapshot: unknown): Record<string, unknown> {
    if (action !== "browserUse.run") return params;
    const task = typeof params.task === "string" ? params.task : "";
    const visualSummary = summarizeVisualParser(snapshot);
    if (!visualSummary) return params;
    return {
      ...params,
      task: `${task}\n\nCurrent YOLO/visual-parser observation from the active Chrome window:\n${visualSummary}\nUse these visible elements as hints, but interact through browser-use.`
    };
  }
}

function isBrowserUseAiFailure(message: string): boolean {
  return /RESOURCE_EXHAUSTED|429|quota|rate-limit|rate limit|ModelProviderError/i.test(message);
}

function buildPrimaryBrowserUseTask(goal: string, language: "hi" | "en"): string {
  const lines = [
    `User command: ${goal}`,
    "",
    "Use browser-use as the main driver in the current Chrome session.",
    "Work directly in the active browser/tab when possible.",
    "Use visible UI and real interactions. If the page needs login, OTP, captcha, payment, password, or a final risky submit not clearly requested by the user, stop and say what the user must do.",
    "When the requested task is complete, stop immediately; do not keep browsing.",
    language === "hi"
      ? "All user-facing status and final response must be in natural, energetic Hindi/Hinglish, addressing the user as boss. Do not answer in English."
      : "All user-facing status and final response must be in clear English."
  ];
  if (isOneShotSubmissionGoal(goal)) {
    lines.push(
      "",
      "One-shot submission guard:",
      "- Send/comment/post/submit the requested text at most once.",
      "- If the exact text is already visible as the latest outgoing message/comment/post, do not send it again; report done.",
      "- Immediately stop after the first successful send/comment/post/submit."
    );
  }
  return lines.join("\n");
}

function browserUseMaxStepsForGoal(goal: string): number {
  return Number(
    isOneShotSubmissionGoal(goal)
      ? process.env.JARVIS_BROWSER_USE_SUBMIT_MAX_STEPS ?? "4"
      : process.env.JARVIS_BROWSER_USE_MAX_STEPS ?? "8"
  );
}

function isOneShotSubmissionGoal(goal: string): boolean {
  return /\b(send|sent|message|comment|post|submit|reply|bhej|bhejo|bhejna|likh\s*kar\s*bhej|comment\s*kar|whatsapp)\b/i.test(goal);
}

function isBrowserUseComplete(result: unknown): boolean {
  if (!result || typeof result !== "object") return false;
  const value = result as Record<string, unknown>;
  return value.engine === "browser-use" && (value.successful === true || value.done === true);
}

function browserUseFinalResult(result: unknown, language: "hi" | "en"): string {
  if (!result || typeof result !== "object") return "";
  const value = result as Record<string, unknown>;
  const raw = typeof value.finalResult === "string" ? value.finalResult : "";
  if (!raw) return "";
  if (language === "hi") {
    if (/login|captcha|otp|password|sign in/i.test(raw)) return "Boss, yahan login ya verification chahiye. Aap ek baar manually kar dijiye, phir main aage sambhal lungi.";
    return "Ho gaya boss, kaam complete kar diya.";
  }
  return raw;
}

function summarizeVisualParser(snapshot: unknown): string {
  if (!snapshot || typeof snapshot !== "object") return "";
  const source = snapshot as Record<string, unknown>;
  const parser = source.visualParser;
  if (!parser || typeof parser !== "object") return "";
  const elements = (parser as { elements?: unknown }).elements;
  if (!Array.isArray(elements)) return "";

  return elements
    .map((item) => {
      if (!item || typeof item !== "object") return "";
      const element = item as Record<string, unknown>;
      const center = element.center && typeof element.center === "object" ? (element.center as Record<string, unknown>) : {};
      const text = typeof element.text === "string" ? element.text.replace(/\s+/g, " ").trim().slice(0, 100) : "";
      const kind = typeof element.kind === "string" ? element.kind : "element";
      const id = typeof element.id === "string" ? element.id : "";
      if (!text && kind === "region") return "";
      if (!text && !["button", "input", "text"].includes(kind)) return "";
      return `${id} ${kind} "${text}" center=(${center.x ?? "?"},${center.y ?? "?"})`;
    })
    .filter(Boolean)
    .slice(0, 25)
    .join("\n");
}

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
}

function extractVisual(snapshot: unknown): { mimeType: string; base64: string } | undefined {
  if (!snapshot || typeof snapshot !== "object") return undefined;
  const value = snapshot as { screenshotMimeType?: unknown; screenshotBase64?: unknown };
  if (typeof value.screenshotMimeType === "string" && typeof value.screenshotBase64 === "string") {
    return { mimeType: value.screenshotMimeType, base64: value.screenshotBase64 };
  }
  return undefined;
}

function sanitizeHistory(history: unknown[]): unknown[] {
  return history.map((entry) => sanitizeSnapshot(entry));
}

function sanitizeSnapshot(value: unknown): unknown {
  if (Array.isArray(value)) return value.map((item) => sanitizeSnapshot(item));
  if (!value || typeof value !== "object") return value;
  const source = value as Record<string, unknown>;
  const copy: Record<string, unknown> = {};
  for (const [key, item] of Object.entries(source)) {
    copy[key] = key === "screenshotBase64" ? "[attached as image]" : sanitizeSnapshot(item);
  }
  return copy;
}

function parseModels(primary?: string, fallbacks?: string): string[] {
  const models = [primary ?? "gemini-2.5-flash", ...(fallbacks ?? "").split(",")]
    .map((model) => model.trim())
    .filter(Boolean);
  return [...new Set(models)];
}

function parseLanguage(value: string | undefined): "hi" | "en" {
  return value?.trim().toLowerCase().startsWith("en") ? "en" : "hi";
}

function phrase(language: "hi" | "en", key: "start" | "done" | "quota" | "stepLimit"): string {
  if (language === "en") {
    return {
      start: "Sure boss, I am working on it now.",
      done: "Done boss, I completed the task.",
      quota: "Boss, the AI model is rate-limited right now. Please try again in a little while.",
      stepLimit: "Boss, this task got too long. Please break it into a smaller command."
    }[key];
  }
  return {
    start: "Theek hai boss, main abhi ye kaam karti hoon. Aap bas ek pal rukiye.",
    done: "Ho gaya boss, kaam complete kar diya.",
    quota: "Boss, AI model abhi rate-limit me atak gaya hai. Thodi der baad dobara try karte hain.",
    stepLimit: "Boss, ye kaam thoda lamba ho gaya. Isko chhote command me bol dijiye, main turant kar dungi."
  }[key];
}

function quickConversationReply(goal: string, language: "hi" | "en"): string {
  const normalized = goal.trim().toLowerCase();
  if (!normalized) return "";
  if (/^(hi|hello|hey|helo|hii|namaste|namaskar|नमस्ते|हेलो|हैलो|हाय|hey jarvis|hello jarvis|jarvis)$/i.test(normalized)) {
    return language === "en" ? "Hello boss, I am ready. What should I do?" : "Namaste boss! Main ready hoon. Batayiye, kya kaam karna hai?";
  }
  if (/^(kaise ho|kese ho|कैसे हो|tum kaise ho|aap kaise ho|how are you)\??$/i.test(normalized)) {
    return language === "en" ? "I am doing great boss, ready for your next command." : "Main badhiya hoon boss, full ready! Aap bas kaam boliye.";
  }
  if (/kya kar rahi|kya kar rhi|kya kar rahe|what are you doing|kya chal raha|क्या कर/i.test(normalized)) {
    return language === "en" ? "I am waiting for your command boss. Tell me what to handle." : "Boss, main yahin hoon, aapke command ka wait kar rahi hoon. Jo kaam bolenge, main sambhal lungi.";
  }
  if (isCasualNonTask(normalized)) {
    return language === "en" ? "Yes boss, I am listening." : "Haan boss, main sun rahi hoon. Aap araam se boliye.";
  }
  return "";
}

function isCasualNonTask(normalized: string): boolean {
  const hasTaskVerb = /\b(open|search|play|click|type|send|message|comment|post|close|download|upload|find|navigate|google|youtube|whatsapp|chrome|tab|video|website|khol|kholo|chala|chalao|laga|lagao|bhej|bhejo|comment|search|dhund|band|likh|type|dabao|click)\b/i.test(normalized);
  if (hasTaskVerb) return false;
  return /(\?$|kaise|kya|kyu|tum|aap|jarvis|boss|hello|hi|hey|batao|baat|sun)/i.test(normalized);
}
