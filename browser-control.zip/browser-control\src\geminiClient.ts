import { z } from "zod";
import { SkillError } from "./protocol.js";

const GeminiResponseSchema = z.object({
  candidates: z
    .array(
      z.object({
        content: z.object({
          parts: z.array(z.object({ text: z.string().optional() }))
        })
      })
    )
    .optional(),
  error: z
    .object({
      message: z.string().optional()
    })
    .optional()
});

export class GeminiClient {
  private readonly models: string[];

  constructor(
    private readonly apiKey: string,
    models: string | string[]
  ) {
    this.models = (Array.isArray(models) ? models : [models])
      .map((model) => model.trim())
      .filter(Boolean);

    if (this.models.length === 0) {
      throw new SkillError("GEMINI_MODEL_MISSING", "No Gemini model configured.");
    }
  }

  async generateJson<T>(
    prompt: string,
    images: Array<{ mimeType: string; base64: string }> = []
  ): Promise<T> {
    let lastError: unknown;

    for (const model of this.models) {
      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          return await this.generateJsonWithModel<T>(model, prompt, images);
        } catch (error) {
          lastError = error;
          if (!isRetryableGeminiError(error)) {
            break;
          }
          await sleep(700 * attempt);
        }
      }
    }

    throw lastError;
  }

  private async generateJsonWithModel<T>(
    model: string,
    prompt: string,
    images: Array<{ mimeType: string; base64: string }>
  ): Promise<T> {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
      model
    )}:generateContent?key=${encodeURIComponent(this.apiKey)}`;

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [
          {
            role: "user",
            parts: [
              { text: prompt },
              ...images.map((image) => ({
                inline_data: {
                  mime_type: image.mimeType,
                  data: image.base64
                }
              }))
            ]
          }
        ],
        generationConfig: {
          temperature: 0.2,
          responseMimeType: "application/json"
        }
      })
    });

    const raw: unknown = await response.json().catch(() => ({}));
    const parsed = GeminiResponseSchema.safeParse(raw);

    if (!response.ok) {
      const message = parsed.success ? parsed.data.error?.message : undefined;
      throw new SkillError("GEMINI_REQUEST_FAILED", message ?? `Gemini request failed with ${response.status}`, {
        status: response.status,
        model
      });
    }

    if (!parsed.success) {
      throw new SkillError("GEMINI_BAD_RESPONSE", "Gemini returned an unexpected response shape.", raw);
    }

    const text = parsed.data.candidates?.[0]?.content.parts.map((part) => part.text ?? "").join("").trim();
    if (!text) {
      throw new SkillError("GEMINI_EMPTY_RESPONSE", "Gemini returned no text.");
    }

    return JSON.parse(stripJsonFence(text)) as T;
  }
}

function stripJsonFence(text: string): string {
  return text.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/\s*```$/i, "").trim();
}

function isRetryableGeminiError(error: unknown): boolean {
  if (!(error instanceof SkillError)) return false;
  const details = error.details as { status?: number } | undefined;
  const message = error.message.toLowerCase();
  return (
    details?.status === 429 ||
    details?.status === 500 ||
    details?.status === 503 ||
    message.includes("high demand") ||
    message.includes("temporarily") ||
    message.includes("try again later") ||
    message.includes("overloaded")
  );
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
